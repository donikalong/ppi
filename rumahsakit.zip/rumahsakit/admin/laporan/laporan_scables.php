
            <!-- Page Content Start -->
            <!-- ================== -->
            <?php
                $dari_tanggal   = $_POST['dari_tanggal'];
                $sampai_tanggal = $_POST['sampai_tanggal'];
				
            ?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><i class="fa fa-file"></i> Laporan Pasien Infeksi Scables</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               <!-- <h3 class="panel-title">Data Siswa</h3> -->
                            </div>
                            <div class="panel-body">
                            <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="" >
                                     
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Dari Tanggal</label>
                                        <div class="col-sm-4">
                                          <input type="text" class="form-control" id="datepicker" name="dari_tanggal" value="<?php echo $dari_tanggal?>" required="">
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Sampai Tanggal</label>
                                        <div class="col-sm-4">
                                          <input type="text" class="form-control" id="datepicker2" name="sampai_tanggal" value="<?php echo $sampai_tanggal?>" required="">
                                        </div>
                                    </div>
                                   
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-2 col-sm-9">
                                          <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Cari</button>
                                          <a href="cetak/cetak_scables.php?dari_tanggal=<?php echo $dari_tanggal?>&sampai_tanggal=<?php echo $sampai_tanggal?>" target="_blank">
                                          <button type="button" class="btn btn-info"><i class="fa fa-print"></i> Cetak</button>
                                          </a>
                                        </div>
                                    </div>
                                </form>
                                <br>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Tanggal</th>
                                                    <th>No Rekam Medis</th>
                                                    <th>Nama Pasien </th>
                                                    <th>Alamat</th>
                                                    <th>Infeksi</th>
                                                    <th>DPJP</th>
                                                    <th>Ruangan</th>
                                                
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
                                                    if (empty($dari_tanggal)){
                                                    $sql = mysql_query("SELECT * FROM rawat inner join pendaftaran on rawat.idpendaftaran = pendaftaran.idpendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan where rawat.infeksi = 'Scables' ");
                                                    } else {
														
                                                     $sql = mysql_query("SELECT * FROM rawat inner join pendaftaran on rawat.idpendaftaran = pendaftaran.idpendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan
                                                            WHERE rawat.infeksi = 'Scables' and rawat.tglmasuk 
                                                            BETWEEN '$dari_tanggal' 
                                                            AND '$sampai_tanggal'");
														
                                                    }
                                                    $no  = 1; 
                                                    while($data = mysql_fetch_array($sql)){
                                                          $tanggal           = $data['tglmasuk'];
                                                          $namapasasien          = $data['namapasien'];
                                                          $alamat        = $data['alamat'];
                                                          $keluhan       = $data['infeksi'];
														  $diagnosa       = $data['namadokter'];
    
                                                      
                                                ?>
                                                <tr>
                                                    <td><?php echo $no++ ?></td>
                                                    <td><?php echo $tanggal ?></td>
                                                    <td><?php echo $data['norm'] ?></td>
                                                    <td><?php echo $namapasasien ?></td>
                                                    <td><?php echo $alamat ?></td>
                                                    <td><?php echo $keluhan ?></td>
                                                    <td><?php echo $diagnosa ?></td>
                                                    <td><?php echo $data['namaruangan'] ?></td>
                                                       </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>
 