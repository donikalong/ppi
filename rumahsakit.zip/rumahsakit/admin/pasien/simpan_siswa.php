<?php 
  
  include "../../inc/config.php";

  
  

  $idpasien         = $_POST['id'];
  $nama        = $_POST['nama'];
  $alamat       = $_POST['alamat'];
  $ttl       = $_POST['ttl'];
  $tl       = $_POST['tl'];
  $telpon       = $_POST['telpon'];
  $nobpjs       = $_POST['nobpjs'];
  @$nama_photo1  = $_FILES['photo1']['name'];
  @$file_type1   = $_FILES['photo1']['type'];
  $type1         = substr($file_type1,6,4);
  $uploaddir     = '../../photo/berita/';
                                     
  $datein1       = date("1-YMDHis");
  $alamatfile1   = $uploaddir.$datein1.'.'.$type1;
  $file_photo1   = $datein1.'.'.$type1;

  if(empty($nama_photo1)){
      $sql   = "INSERT INTO pasien VALUES(null,'$judul','$berita',null,'$tanggal')";
      $query = mysql_query($sql);
  }
  else if(@$file_type1  !=  "image/gif"  &&  @$file_type1  !=  "image/jpg"  && @$file_type1 != "image/jpeg" && @$file_type1 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../index.php?mod=berita&pg=form_input_berita';
                </script> 
        <?php
      } 
  
  else {

      
        
     
      move_uploaded_file($_FILES['photo1']['tmp_name'],$alamatfile1);

      $sql   = "INSERT INTO tbl_berita VALUES(null,'$judul','$berita','$tanggal','$file_photo1')";

      $query = mysql_query($sql);
   }
      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=berita&pg=data_berita";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=berita&pg=form_input_berita";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>