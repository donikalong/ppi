
<?php 
    $idpasien = $_GET['idpasien'];
    $sql   = "SELECT * FROM pasien WHERE idpasien='$idpasien'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><button class="btn btn-success m-b-5" onclick="self.history.back()"> <i class="fa fa-arrow-left"></i> <span>Kembali</span> </button></h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               <!-- <h3 class="panel-title">Data Siswa</h3> -->
                            <Form method="post" name="form1" action="siswa/simpan_siswa.php" enctype="multipart/form-data">
                                    <table class="table table-boxed">
                                        <thead>
                                            <tr>
                                                <th colspan="3"><h2 style="text-align:center;">Biodata Pasien</h2></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Email</td>
                                                <td>
                                                     <?php echo $data['idpasien'];?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama Pasien</td>
                                                <td width="239"> <?php echo $data['namapasien'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Alamat</td>
                                                <td> <?php echo $data['alamat'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Telpon</td>
                                                <td> <?php echo $data['telpon'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">No BPJS</td>
                                                <td> <?php echo $data['nobpjs'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Jenis Kelamin</td>
                                                <td>
                                                     <?php echo $data['jk'];?>  
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Pekerjaan</td>
                                                <td>
                                                    <?php echo $data['pekerjaan'];?> 
                                                </td>
                                            </tr>
                                           
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Foto BPJS / KTP</td>
                                                <td><a href="../photo/bpjs/<?php echo $data['foto']?>"><img src="../photo/bpjs/<?php echo $data['foto']?>" width="100px" height="100px"></a></td>
                                            </tr>
                                            
                                             
                                        </tbody>
                                    </table>
									</form>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           