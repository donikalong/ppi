<?php 

    include "../../inc/config.php";

    $idpasien = $_GET['idpasien'];
    $sql   = "DELETE FROM pasien WHERE nik='$idpasien'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=pasien&pg=data_pasien'</script>";
 ?>