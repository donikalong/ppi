<?php 
  error_reporting(0);
  include "../../inc/config.php";

  $id_daftar    = $_POST['id_daftar'];
  $jenjang      = $_POST['jenjang'];
  $nama         = $_POST['nama'];
  $nisn         = $_POST['nisn'];
  $tempat_lahir = $_POST['tempat_lahir'];
  $tgl_lahir    = $_POST['tgl_lahir'];
  $jenis_kelamin= $_POST['jenis_kelamin'];
  $agama        = $_POST['agama'];
  $nama_orangtua= $_POST['nama_orangtua'];
  $alamat_siswa = $_POST['alamat_siswa'];
  $telp         = $_POST['telp'];
  $asal_sekolah = $_POST['asal_sekolah'];
  $b_indonesia  = $_POST['b_indonesia'];
  $matematika   = $_POST['matematika'];
  $ipa          = $_POST['ipa'];
  $b_inggris    = $_POST['b_inggris'];
  $rata_rata    = $_POST['rata_rata'];
  $piagam       = $_POST['piagam'];
  $mengetahui   = $_POST['mengetahui'];
  $tanggal      = $_POST['tanggal'];
  $foto1        = $_POST['foto1'];
  $foto2        = $_POST['foto2'];
  $foto3        = $_POST['foto3'];
  
  $uploaddir    = '../../photo/';

  //FOTO1
  $nama_photo1  = $_FILES['photo1']['name'];
  $file_type1   = $_FILES['photo1']['type'];
  $type1        = substr($file_type1,6,4);
                                 
  $datein1      = date("1-YMDHis");
  $alamatfile1  = $uploaddir.$datein1.'.'.$type1;
  $file_photo1  = $datein1.'.'.$type1;

  //FOTO2
  $nama_photo2  = $_FILES['photo2']['name'];
  $file_type2   = $_FILES['photo2']['type'];
  $type2        = substr($file_type2,6,4); 
                                     
  $datein2      = date("2-YMDHis");
  $alamatfile2  = $uploaddir.$datein2.'.'.$type2;
  $file_photo2  = $datein2.'.'.$type2;

  //FOTO3
  $nama_photo3  = $_FILES['photo3']['name'];
  $file_type3   = $_FILES['photo3']['type'];
  $type3        = substr($file_type3,6,4); 
                                     
  $datein3      = date("3-YMDHis");
  $alamatfile3  = $uploaddir.$datein3.'.'.$type3;
  $file_photo3  = $datein3.'.'.$type3;


  if (!empty($nama_photo1)){

  if(@$file_type1  !=  "image/gif"  &&  @$file_type1  !=  "image/jpg"  && @$file_type1 != "image/jpeg" && @$file_type1 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../index.php?mod=siswa&pg=form_edit_siswa&id_daftar=<?php echo $id_daftar?>';
                </script> 
        <?php
      } 
  else {
      
      unlink('../../photo/'.$foto1);
      move_uploaded_file($_FILES['photo1']['tmp_name'],$alamatfile1);

        $sql1   = "UPDATE tbl_daftar SET jenjang='$jenjang',nama='$nama',nisn='$nisn',
                tempat_lahir='$tempat_lahir',tgl_lahir='$tgl_lahir',jenis_kelamin='$jenis_kelamin',
                agama='$agama',nama_orangtua='$nama_orangtua',alamat_siswa='$alamat_siswa',telp='$telp',
                asal_sekolah='$asal_sekolah',b_indonesia='$b_indonesia',matematika='$matematika',
                ipa='$ipa',b_inggris='$b_inggris',rata_rata='$rata_rata',piagam='$piagam',
                mengetahui='$mengetahui',tanggal='$tanggal',photo1='$file_photo1'
                WHERE id_daftar='$id_daftar'";

        $query1 = mysql_query($sql1);
    }
} 

if (!empty($nama_photo2)){

  if(@$file_type2  !=  "image/gif"  &&  @$file_type2  !=  "image/jpg"  && @$file_type2 != "image/jpeg" && @$file_type2 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../index.php?mod=siswa&pg=form_edit_siswa&id_daftar=<?php echo $id_daftar?>';
                </script> 
        <?php
      } 
  else {
      unlink('../../photo/'.$foto2);
      move_uploaded_file($_FILES['photo2']['tmp_name'],$alamatfile2);

        $sql2   = "UPDATE tbl_daftar SET jenjang='$jenjang',nama='$nama',nisn='$nisn',
                tempat_lahir='$tempat_lahir',tgl_lahir='$tgl_lahir',jenis_kelamin='$jenis_kelamin',
                agama='$agama',nama_orangtua='$nama_orangtua',alamat_siswa='$alamat_siswa',telp='$telp',
                asal_sekolah='$asal_sekolah',b_indonesia='$b_indonesia',matematika='$matematika',
                ipa='$ipa',b_inggris='$b_inggris',rata_rata='$rata_rata',piagam='$piagam',
                mengetahui='$mengetahui',tanggal='$tanggal',photo2='$file_photo2'
                WHERE id_daftar='$id_daftar'";

        $query2 = mysql_query($sql2);
    }
}

if (!empty($nama_photo3)){

  if(@$file_type3  !=  "image/gif"  &&  @$file_type3  !=  "image/jpg"  && @$file_type3 != "image/jpeg" && @$file_type3 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../index.php?mod=siswa&pg=form_edit_siswa&id_daftar=<?php echo $id_daftar?>';
                </script> 
        <?php
      } 
  else {
      unlink('../../photo/'.$foto3);
      move_uploaded_file($_FILES['photo3']['tmp_name'],$alamatfile3);

        $sql3   = "UPDATE tbl_daftar SET jenjang='$jenjang',nama='$nama',nisn='$nisn',
                tempat_lahir='$tempat_lahir',tgl_lahir='$tgl_lahir',jenis_kelamin='$jenis_kelamin',
                agama='$agama',nama_orangtua='$nama_orangtua',alamat_siswa='$alamat_siswa',telp='$telp',
                asal_sekolah='$asal_sekolah',b_indonesia='$b_indonesia',matematika='$matematika',
                ipa='$ipa',b_inggris='$b_inggris',rata_rata='$rata_rata',piagam='$piagam',
                mengetahui='$mengetahui',tanggal='$tanggal',photo3='$file_photo3'
                WHERE id_daftar='$id_daftar'";

        $query3 = mysql_query($sql3);
    }
}

if (empty($nama_photo1) && empty($nama_photo2) && empty($nama_photo3)){

  

        $sql4   = "UPDATE tbl_daftar SET jenjang='$jenjang',nama='$nama',nisn='$nisn',
                tempat_lahir='$tempat_lahir',tgl_lahir='$tgl_lahir',jenis_kelamin='$jenis_kelamin',
                agama='$agama',nama_orangtua='$nama_orangtua',alamat_siswa='$alamat_siswa',telp='$telp',
                asal_sekolah='$asal_sekolah',b_indonesia='$b_indonesia',matematika='$matematika',
                ipa='$ipa',b_inggris='$b_inggris',rata_rata='$rata_rata',piagam='$piagam',
                mengetahui='$mengetahui',tanggal='$tanggal'
                WHERE id_daftar='$id_daftar'";

        $query4 = mysql_query($sql4); 
} 
  if ($query1 || $query2 || $query3 || $query4){
    ?>
        <script type="text/javascript">
        alert("Data siswa berhasil diubah");
        document.location="../index.php?mod=siswa&pg=data_siswa";
        </script>
    <?php
  }
  else{
        ?>
        <script type="text/javascript">
        alert("Data siswa gagal diubah");
        document.location="../index.php?mod=siswa&pg=data_siswa";
        </script>
    <?php 
  }  
  mysql_close();


 ?>