<?php 

    include "../../inc/config.php";

    $id_obat = $_GET['id_obat'];

    $sql   = "DELETE FROM obat WHERE kodeobat='$id_obat'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=obat&pg=data_obat'</script>";
 ?>