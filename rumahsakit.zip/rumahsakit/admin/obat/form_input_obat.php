

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Input Data Obat</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="obat/simpan_obat.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Kode Obat</label>
                                        <div class="col-sm-10">
                                           <input name="kode" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama Obat</label>
                                        <div class="col-sm-10">
                                           <input name="nama" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Harga Obat</label>
                                        <div class="col-sm-10">
                                           <input name="harga" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Stok</label>
                                        <div class="col-sm-10">
                                           <input name="stok" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Jenis</label>
                                        <div class="col-sm-10">
                                           <select name="jenis" class="form-control">
                                            <option value="Syrup">Syrup</option>
                                            <option value="Tablet">Tablet</option>
                                            <option value="Kapsul">Kapsul</option>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Dosis</label>
                                        <div class="col-sm-10">
                                           <select name="dosis" class="form-control">
                                            <option value="gram">gram</option>
                                            <option value="ml">ml</option>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           
