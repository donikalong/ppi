<?php 
  
  include "../../inc/config.php";

  
  

  $kode    = $_POST['kode'];
  $nama         = $_POST['nama'];
  $stok         = $_POST['stok'];
  $harga      = $_POST['harga'];
  $jenis  = $_POST['jenis'];
  $dosis = $_POST['dosis'];
  
      $sql   = "UPDATE obat SET namaobat='$nama', stok='$stok', harga='$harga', jenis='$jenis', dosis='$dosis'
                WHERE kodeobat='$kode'";

      $query = mysql_query($sql);

      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data berhasil disimpan");
        document.location="../index.php?mod=obat&pg=data_obat";
        </script>
      <?php
      }
      else{
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=obat&pg=form_input_obat";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>