<?php 
  
  include "../../inc/config.php";

  
  

  $nama         = $_POST['nama'];
  $stok         = $_POST['stok'];
  $harga         = $_POST['harga'];
  $kode         = $_POST['kode'];
  $jenis  = $_POST['jenis'];
  $dosis = $_POST['dosis'];
  
      $sql   = "INSERT INTO obat VALUES('$kode','$nama','$harga','$stok','$jenis','$dosis')";

      $query = mysql_query($sql);
      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=obat&pg=data_obat";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=obat&pg=form_input_obat";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>