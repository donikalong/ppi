<?php 

    include "../../inc/config.php";

    $id_ruangan = $_GET['idruangan'];

    $sql   = "DELETE FROM ruangan WHERE idruangan='$id_ruangan'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=ruangan&pg=data_ruangan'</script>";
 ?>