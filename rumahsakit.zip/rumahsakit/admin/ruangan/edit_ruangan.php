<?php 
  
  include "../../inc/config.php";

  
  

  $kode    = $_POST['kode'];
  $nama    = $_POST['nama'];
  $kelas   = $_POST['kelas'];
  
      $sql   = "UPDATE ruangan SET namaruangan='$nama', kelas='$kelas'
                WHERE idruangan='$kode'";

      $query = mysql_query($sql);

      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data berhasil disimpan");
        document.location="../index.php?mod=ruangan&pg=data_ruangan";
        </script>
      <?php
      }
      else{
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=ruangan&pg=form_input_ruangan";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>