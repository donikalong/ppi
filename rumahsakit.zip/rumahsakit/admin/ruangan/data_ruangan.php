
            <!-- Page Content Start -->
            <!-- ================== -->
      
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Daftar Ruangan</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                            <h3 class="panel-title" style="text-align:right"><a href="index.php?mod=ruangan&pg=form_input_ruangan"><button class="btn btn-success m-b-5"> <i class="fa fa-plus"></i> <span>Tambah Data</span> </button>
                                </a>
                                 </h3>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Kode Ruangan</th>
                                                    <th>Nama Ruangan</th>
                                                    <th>Kelas</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM ruangan ORDER BY namaruangan ASC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['idruangan'] ?></td>
                                                    <td><?php echo $data['namaruangan'] ?></td>
													<td><?php echo $data['kelas'] ?></td>
                                                     <td>
                                                           
                                                       <a href="index.php?mod=ruangan&pg=form_edit_ruangan&idruangan=<?php echo $data['idruangan'];?>"><button class="btn btn-icon btn-info m-b-5"> <i class="fa fa-eye"></i> </button></a>

                                                     
                                                        <a href="ruangan/hapus_ruangan.php?idruangan=<?php echo $data['idruangan'];?>" onclick="return confirm('Apakah anda yakin ingin menghapus data?') ";><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           