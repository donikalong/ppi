
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join rawat on pendaftaran.idpendaftaran = rawat.idpendaftaran inner join isk on rawat.idrawat = isk.idrawat inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir ISK</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data"  >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['namadokter'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['namaruangan'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Jenis Pemasangan</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['jp'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Pemeriksaan</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['pemeriksaan'] ?>" readonly>
                                        
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Pemeriksaan</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['tglpemeriksaan'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Keterangan</label>
                                        <div class="col-sm-10">
                                        <textarea style="width: 100%; height: 50px;" name="keterangan" readonly><?php echo $data['keterangan'] ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Pasang</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['tglpasang'] ?>" readonly>
                                        </div>
                                    </div>
                                                        
                                    <div class="form-group">
                                    <table border="0" width="100%">
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputEmail3" class="col-sm-12 control-label">Pemasangan DC Sesuai Indikasi</label>
                                        </td>
                                        <td width="40%"> 
                                        <input class="form-control" value="<?php echo $data['sesuaidc'] ?>" readonly>
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Pemasangan Menggunakan Alat Steril</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['steril'] ?>" readonly>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Melakukan Hand Hyglene</label>
                                        </td>
                                        <td width="40%">
                                        <input class="form-control" value="<?php echo $data['handhyglen'] ?>" readonly>
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Segera Dilepas Jika Tidak Indikasi</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['lepasindikasi'] ?>" readonly>
                                        </td>
                                     </tr>
                                     <tr>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Fiksasi Kateter dengan Plester</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['plester'] ?>" readonly>
                                        </td>
                                        <td width="20%"> 
                                        <label for="inputPassword3" class="col-sm-12 control-label">Pengisian Balon sesuai indikasi (30ml)</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['balon'] ?>" readonly>
                                        </td>
                                     </tr>
                                     <tr>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">ADP Tepat</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['adp'] ?>" readonly>
                                        </td>
                                        <td width="20%"> 
                                        <label for="inputPassword3" class="col-sm-12 control-label">Urine Bag Menggantung</label>
                                        </td>
                                        <td width="30%">
                                        <input class="form-control" value="<?php echo $data['bagurine'] ?>" readonly>
                                        </td>
                                     </tr>
                                    </table>
                                    <br>
                                    </div>
                                    
                                    
                            </form>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                        <a href="index.php?mod=rekam&pg=data_rekam"><button  class="btn btn-info">Kembali</button></a>
                                        </div>
                                    </div>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     