
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join rawat on pendaftaran.idpendaftaran = rawat.idpendaftaran inner join dekubitus on rawat.idrawat = dekubitus.idrawat inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir Dekubitus</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data"  >
                            
                                      <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                           <input class="form-control" value="<?php echo $data['namadokter'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['namaruangan'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Kondisi</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['kondisi'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Status Mental</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['mental'] ?>" readonly>
                                        </div>
                                    </div>
                       
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Aktifitas</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['aktifitas'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Mobilitas</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['mobilitas'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ikontinensia</label>
                                        <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo $data['inkontinensia'] ?>" readonly>
                                        </div>
                                    </div>
                                    <br>
                            </form>   
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <a href="index.php?mod=rekam&pg=data_rekam"><button  class="btn btn-info">Kembali</button></a>
                                        </div>
                                    </div>
                               
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     