
			 <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Ruang Rawat Inap</h3> 
                </div>

                <div class="row">
					<?php
					$sqlruang = mysql_query("SELECT * FROM ruangan order by namaruangan asc");
					while ($dtruang = mysql_fetch_array($sqlruang)){
						$idruang = $dtruang ['idruangan'];
						$sqljmr = mysql_query("SELECT * FROM rawat where idruangan='$idruang'");
						$jmr	= mysql_num_rows($sqljmr);
					?>
					<div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-pink">
                            <i class="ion-calendar"></i> 
                            <h2 class="m-0 counter"><?php echo $jmr ?></h2>
                            <div><?php echo $dtruang['namaruangan'] ?> </div>
                        </div>
                	</div>
					<?php
					}
					?>
		       </div> <!-- end row -->
			   <div class="page-title"> 
                    <h3 class="title">Jenis Infeksi</h3> 
                </div>
				<div class="row">
					<?php
					$sqlisk = mysql_query("SELECT * FROM rawat where infeksi='ISK'");
					$jmisk	= mysql_num_rows($sqlisk);

					$sqlp = mysql_query("SELECT * FROM rawat where infeksi='Phlebitis'");
					$jmp	= mysql_num_rows($sqlp);

					$sqls = mysql_query("SELECT * FROM rawat where infeksi='Scables'");
					$jms	= mysql_num_rows($sqls);

					$sqld = mysql_query("SELECT * FROM rawat where infeksi='Dekubitus'");
					$jmd	= mysql_num_rows($sqld);
					?>
				<div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-primary">
                            <i class="ion-calendar"></i> 
                            <h2 class="m-0 counter"><?php echo $jmp ?></h2>
                            <div>Phlebitis </div>
                        </div>
                </div>
				<div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-pink">
                            <i class="ion-calendar"></i> 
                            <h2 class="m-0 counter"><?php echo $jmisk ?></h2>
                            <div>ISK </div>
                        </div>
                </div>
				<div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-purple">
                            <i class="ion-calendar"></i> 
                            <h2 class="m-0 counter"><?php echo $jms ?></h2>
                            <div>Scables </div>
                        </div>
                </div>
				<div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-primary">
                            <i class="ion-calendar"></i> 
                            <h2 class="m-0 counter"><?php echo $jmd ?></h2>
                            <div>Dekubitus </div>
                        </div>
                </div>
                </div> <!-- end row -->
			
		
            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->
