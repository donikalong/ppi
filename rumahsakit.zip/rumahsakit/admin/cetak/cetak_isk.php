<?php
// memanggil library FPDF
require('fpdf.php');
// intance object dan memberikan pengaturan halaman PDF
$pdf = new FPDF('l','mm','A5');
// membuat halaman baru
$pdf->AddPage();
// setting jenis font yang akan digunakan
$pdf->SetFont('Arial','B',16);
// mencetak string 
$pdf->Cell(190,7,'RUMAH SAKIT ERNALDI BAHAR',0,1,'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(190,7,'DAFTAR PASIEN INFEKSI ISK',0,1,'C');

// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(30,6,'No Rekam Medis',1,0);
$pdf->Cell(30,6,'Nama Pasien',1,0);
$pdf->Cell(60,6,'Alamat',1,0);
$pdf->Cell(20,6,'Infeksi',1,0);
$pdf->Cell(20,6,'DPJP',1,0);
$pdf->Cell(20,6,'Ruangan',1,1);

$pdf->SetFont('Arial','',10);

include '../../inc/config.php';
$dari   = $_GET['dari_tanggal'];
$sampai = $_GET['sampai_tanggal'];

if (empty($dari)){
    $sql = mysql_query("SELECT * FROM rawat inner join pendaftaran on rawat.idpendaftaran = pendaftaran.idpendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan inner join isk on rawat.idrawat = isk.idrawat where rawat.infeksi = 'ISK' ");
    } else {
        
     $sql = mysql_query("SELECT * FROM rawat inner join pendaftaran on rawat.idpendaftaran = pendaftaran.idpendaftaran inner join pasien on pendaftaran.norm = pasien.norm inner join dokter on rawat.iddokter = dokter.iddokter inner join ruangan on rawat.idruangan = ruangan.idruangan isk on rawat.idrawat = isk.idrawat
            WHERE rawat.infeksi = 'ISK' and rawat.tglmasuk 
            BETWEEN '$dari_tanggal' 
            AND '$sampai_tanggal'");
        
    }
while ($row = mysql_fetch_array($sql)){
    $pdf->Cell(30,6,$row['norm'],1,0,'C');
    $pdf->Cell(30,6,$row['namapasien'],1,0,'C');
    $pdf->Cell(60,6,$row['alamat'],1,0,'C');
    $pdf->Cell(20,6,$row['infeksi'],1,0,'C');
    $pdf->Cell(20,6,$row['namadokter'],1,0,'C');
$pdf->Cell(20,6,$row['namaruangan'],1,1,'C'); 
}

$pdf->Output();
?>