<?php 
    error_reporting(0);
    include "../../inc/config.php";

    $id_perawat = $_GET['id_perawat'];
    $foto = $_GET['foto'];
    unlink('../../photo/perawat/'.$foto);
    $sql   = "DELETE FROM perawat WHERE idperawat='$id_perawat'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=perawat&pg=data_perawat'</script>";
 ?>