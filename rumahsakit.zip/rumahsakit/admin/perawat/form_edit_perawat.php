<?php
  $id_perawat = $_GET['id_perawat'];
  $sql = mysql_query("SELECT * FROM perawat WHERE idperawat='$id_perawat'");
  $data= mysql_fetch_assoc($sql);
?>

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Edit Data Perawat</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="perawat/edit_perawat.php" >
                                <input class="form-control" type="hidden" name="id_perawat" value="<?php echo $data['idperawat']?>">

                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">NIP</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="nip" value="<?php echo $data['idperawat']?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama perawat</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="nama" value="<?php echo $data['namaperawat']?>">
                                        </div>
                                    </div>
                       
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Alamat</label>
                                        <div class="col-sm-8">
                                          <textarea class="form-control" name="alamat" value=""><?php echo $data['alamat']?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Telepon</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="no_telp" value="<?php echo $data['telpon']?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Foto</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="hidden" name="photo" value="<?php echo $data['foto']?>">
                                          <input class="form-control" type="file" name="photo1" value="">
                                        </div>
                                    </div>                              
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
       
 