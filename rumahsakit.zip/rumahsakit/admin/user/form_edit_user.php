

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Ubah Password</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">


                              <?php 
                                  $id_user = $_SESSION['username'];
                                  $sql   = "SELECT * FROM login WHERE username='$id_user'";
                                  $query = mysql_query($sql);
                                  $data  = mysql_fetch_array($query); 

                               ?>
                                <form class="form-horizontal" action="../../pasien/user/user/edit_user.php" method="POST" >
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-3 control-label">Username</label>
                                        <div class="col-sm-9">
                                          <input type="hidden" class="form-control" name="id_user" value="<?php echo $data['username'];?>" required>
                                          <input type="text" class="form-control" name="username" value="<?php echo $data['username'];?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-3 control-label">Password</label>
                                        <div class="col-sm-9">
                                          <input type="password" class="form-control" name="password"  required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-3 control-label">Konfirmasi Password</label>
                                        <div class="col-sm-9">
                                          <input type="password" class="form-control" name="password2"  required>
                                        </div>
                                    </div>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button> 
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div> <!-- End row -->

            </div>
           