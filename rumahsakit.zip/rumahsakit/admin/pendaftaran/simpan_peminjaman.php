<?php 
  
  include "../../inc/config.php";

  
  

  $nama         = $_POST['barang'];
  $namapetugas         = $_POST['petugas'];
  $jumlah         = $_POST['jumlah'];
  $tgl = $_POST['Y-m-d'];
  
      $sql   = "INSERT INTO peminjaman VALUES('','$tgl','$namapetugas','$nama','$jumlah')";

      $query = mysql_query($sql);
      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=peminjaman&pg=data_peminjaman";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=peminjaman&pg=form_input_peminjaman";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>