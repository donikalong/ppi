<?php 
  
  include "../../inc/config.php";

  
  

  $nama         = $_POST['nama'];
  $namapetugas         = $_POST['namapetugas'];
  $jumlah         = $_POST['jumlah'];
  $tgl = $_POST['Y-m-d'];
  
  
      $sql   = "UPDATE peminjaman SET nik='$namapetugas', kodebarang='$nama', jumlahpinjam='$jumlah'
                WHERE idpeminjaman='$kode'";

      $query = mysql_query($sql);

      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data berhasil disimpan");
        document.location="../index.php?mod=peminjaman&pg=data_peminjaman";
        </script>
      <?php
      }
      else{
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=peminjaman&pg=form_input_peminjaman";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>