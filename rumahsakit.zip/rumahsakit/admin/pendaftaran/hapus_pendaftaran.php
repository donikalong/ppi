<?php 

    include "../../inc/config.php";

    $id_obat = $_GET['id_pendaftaran'];

    $sql   = "DELETE FROM pendaftaran WHERE idpendaftaran='$id_obat'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=peminjaman&pg=data_peminjaman'</script>";
 ?>