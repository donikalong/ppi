

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Input Peminjaman Barang</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="peminjaman/simpan_peminjaman.php" >
                                     <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama Barang</label>
                                        <div class="col-sm-10">
                                           <select name="barang" class="form-control">
                                           <?php
										   $sql = mysql_query("select * from barang");
										   while($dt = mysql_fetch_array($sql)){
										   ?>
                                           <option value="<?php echo $dt['kodebarang']?>"><?php echo $dt['namabarang']?></option>
                                           <?php } ?>
                                           </select>
                                        </div>
                                    </div>
                                       <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama Petugas</label>
                                        <div class="col-sm-10">
                                           <select name="petugas" class="form-control">
                                           <?php
										   $sql = mysql_query("select * from petugas");
										   while($dt = mysql_fetch_array($sql)){
										   ?>
                                           <option value="<?php echo $dt['nik']?>"><?php echo $dt['nik']?><?php echo $dt['namapetugas']?></option>
                                           <?php } ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Jumlah</label>
                                        <div class="col-sm-10">
                                           <input name="jumlah" class="form-control"  />
                                        </div>
                                    </div>
                                        
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           
