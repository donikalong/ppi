<?php 
  
  include "../../inc/config.php";

  
  

  $id         = $_POST['iddaftar'];
  $obat         = $_POST['obat'];
  $jml         = $_POST['jml'];
  $nopembayaran = $_POST['nopembayaran'];
  $rr = mysql_query("select * from obat where kodeobat='$obat'");
  $jk = mysql_fetch_array($rr);
  $harga = $jk['harga'];
  $total = $jml*$harga ;
  $stok = $jk['stok'];
  
      $sql   = "INSERT INTO resep VALUES('$id','$obat','$jml','$total','$nopembayaran')";

      $query = mysql_query($sql);
      if ($query) {
        $sisa = $stok - $jml ;
        mysql_query("update obat set stok='$sisa' where kodeobat='$obat'");
       ?>
        <script type="text/javascript">
        document.location="../index.php?mod=resep&pg=form_input_resep&id_daftar=<?php echo $id ?>";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=resep&pg=form_input_resep&id_daftar=<?php echo $id ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>