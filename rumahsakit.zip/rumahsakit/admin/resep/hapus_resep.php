<?php 

    include "../../inc/config.php";

    $noresep = $_GET['noresep'];
	$kodeobat = $_GET['kodeobat'];

    $sql   = "DELETE FROM resep WHERE noresep='$noresep' and kodeobat='$kodeobat'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=rekam&pg=data_rekam'</script>";
 ?>