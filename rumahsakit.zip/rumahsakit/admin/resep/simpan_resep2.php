<?php 
  
  include "../../inc/config.php";

  
  

  $id         = $_POST['iddaftar'];
  $obat         = $_POST['obat'];
  $jml         = $_POST['jml'];
  $nopembayaran = $_POST['nopembayaran'];
  $rr = mysql_query("select * from obat where kodeobat='$obat'");
  $jk = mysql_fetch_array($rr);
  $harga = $jk['harga'];
  $total = $jml*$harga ;
  
      $sql   = "INSERT INTO rawatjalan VALUES('','$id','$id')";

      $query = mysql_query($sql);
      if ($query) {
       ?>
        <script type="text/javascript">
        document.location="../index.php?mod=resep&pg=form_input_resep&id_daftar=<?php echo $id ?>";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=resep&pg=form_input_resep&id_daftar=<?php echo $id ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>