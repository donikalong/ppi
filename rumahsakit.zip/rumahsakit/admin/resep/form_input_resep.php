

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Input Resep Obat</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="resep/simpan_resep.php" >
                                    <div class="form-group">
                                    <?php
									$id = $_GET['id_daftar'];
									$sl = mysql_query("select * from rekammedis inner join pendaftaran on rekammedis.nopendaftaran = pendaftaran.nopendaftaran inner join pasien on pendaftaran.idpasien = pasien.idpasien where rekammedis.nopendaftaran = '$id'");
									$kk = mysql_fetch_array($sl);
									
									$nopembayaran=mysql_query("SELECT * FROM pembayaran ");
	$nomer=mysql_num_rows($nopembayaran);
	$no=$nomer + 1;
									?>
                                    <input type="hidden" name="nopembayaran" value="<?php echo $no ?>">
                                    <input type="hidden" name="iddaftar" value="<?php echo $id ?>"  />
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama Pasien</label>
                                        <div class="col-sm-10">
                                           <input name="nama" value="<?php echo $kk['namapasien'] ?>" readonly="readonly" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label>
                                        <div class="col-sm-10">
                                           <input name="stok" value="<?php echo $kk['keluhan'] ?>" readonly="readonly" class="form-control"  />
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Pemeriksaan</label>
                                        <div class="col-sm-10">
                                           <input name="stok" value="<?php echo $kk['pemeriksaan'] ?>"  readonly="readonly" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Obat</label>
                                        <div class="col-sm-10">
                                           <select name="obat" class="form-control" >
                                           <?php
										   $fg = mysql_query("select * from obat order by namaobat asc");
										   while ($gg = mysql_fetch_array($fg)){
										   ?>
                                           <option value="<?php echo $gg['kodeobat'] ?>"><?php echo $gg['namaobat'] ?></option>
                                           
                                           <?php } ?>
                                           </select>
                                        </div>
         
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Jumlah Obat</label>
                                        <div class="col-sm-10">
                                           <input name="jml" class="form-control"  />
                                        </div>
                                    </div>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Tambah</button>
                                          
                                        </div>
                                    </div>
                                </form>
                                <h4>Tabel Resep</h4>
                                <table align="center" class="table table-striped table-bordered" width="100%" >
                                <tr>
                                <th>Nama Obat</th>
                                <th>Jumlah</th>
                                <th>total</th>
                                <th>Aksi</th>
                                </tr>
								<?php
								$ft = mysql_query("select * from resep inner join obat on resep.kodeobat = obat.kodeobat where resep.noresep='$id'");
								while ($kk = mysql_fetch_array($ft)){
								?>
                                <tr>
                                <td><?php echo $kk['namaobat'] ?></td>
                                <td><?php echo $kk['jumlah'] ?></td>
                                <td><?php echo $kk['total'] ?></td>
                                <td> <a href="resep/hapus_resep.php?noresep=<?php echo $kk['noresep'];?>&kodeobat=<?php echo $kk['kodeobat'];?>" ;><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a></td>
                                </tr>
								<?php } ?>
                                </table>
                                
                                
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           
