
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Obat</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title" style="text-align:right"><a href="index.php?mod=obat&pg=form_input_obat"><button class="btn btn-success m-b-5"> <i class="fa fa-plus"></i> <span>Tambah Data</span> </button>
                                </a>
                                 </h3>

                            </div>
                            <div class="panel-body">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Obat</th>
                                                    <th>Stok</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM obat order by namaobat asc");
                                                    $no  = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++; ?></td>
                                                    <td><?php echo $data['namaobat']; ?></td>
                                                    <td><?php echo $data['stok']; ?></td>
                                                    <td>
                                                        <a href="index.php?mod=obat&pg=form_edit_obat&id_obat=<?php echo $data['kodeobat'];?>"><button class="btn btn-icon btn-primary m-b-5"> <i class="fa fa-edit"></i> </button></a>
                                                        <a href="obat/hapus_obat.php?id_obat=<?php echo $data['kodeobat'];?>" onclick="return confirm('Apakah anda yakin ingin menghapus data?') ";><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a>                                                       
                                                    </td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           