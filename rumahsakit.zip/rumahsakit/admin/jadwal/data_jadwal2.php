
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Jadwal Petugas</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                

                            </div>
                            <div class="panel-body">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Petugas</th>
                                                    <th>Hari</th>
                                                    <th>Jam</th>
                                                  </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM jadwal inner join petugas on jadwal.kodejadwal = petugas.kodejadwal order by petugas.namapetugas asc");
                                                    $no  = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++; ?></td>
                                                    <td><?php echo $data['namapetugas']; ?></td>
                                                    <td><?php echo $data['hari']; ?></td>
                                                    <td><?php echo $data['jam']; ?></td>
                                                  </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           