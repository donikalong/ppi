<?php 
  
  include "../../inc/config.php";

  
  

  $petugas         = $_POST['petugas'];
  $hari         = $_POST['hari'];
  $jam         = $_POST['jam'];
  
      $sql   = "INSERT INTO jadwal VALUES(null,'$hari','$jam')";

      $query = mysql_query($sql);
      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=jadwal&pg=data_jadwal";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=jadwal&pg=form_input_jadwal";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>