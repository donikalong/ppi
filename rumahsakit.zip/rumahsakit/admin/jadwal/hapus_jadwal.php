<?php 

    include "../../inc/config.php";

    $id_jadwal = $_GET['id_jadwal'];

    $sql   = "DELETE FROM jadwal WHERE kodejadwal='$id_jadwal'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=jadwal&pg=data_jadwal'</script>";
 ?>