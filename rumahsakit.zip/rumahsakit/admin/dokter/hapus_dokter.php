<?php 
    error_reporting(0);
    include "../../inc/config.php";

    $id_dokter = $_GET['id_dokter'];
    $foto = $_GET['foto'];
    unlink('../../photo/dokter/'.$foto);
    $sql   = "DELETE FROM dokter WHERE iddokter='$id_dokter'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=dokter&pg=data_dokter'</script>";
 ?>