

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Input Data Dokter</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="dokter/simpan_dokter.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">NIP Dokter</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="nip" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Nama dokter</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="nama" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Spesialis</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="text" name="spesialis" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Foto</label>
                                        <div class="col-sm-8">
                                          <input class="form-control" type="file" name="photo1" value="">
                                        </div>
                                    </div>                              
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
  