<?php 
  
  include "../../inc/config.php";

  $nip          = $_POST['nip'];
  $pass         = md5($nip);
  $nama         = $_POST['nama'];
  $spesialis    = $_POST['spesialis'];
  $nama_photo1 = $_FILES['photo1']['name'];
  $file_type1  = $_FILES['photo1']['type'];
  $type1        = substr($file_type1,6,4);
  $uploaddir    = '../../photo/dokter/';
                                     
  $datein1       = date("1-YMDHis");
  $alamatfile1   = $uploaddir.$datein1.'.'.$type1;
  $file_photo1   = $datein1.'.'.$type1;

  if(empty($nama_photo1)){
      $sql   = "INSERT INTO dokter VALUES('$nip','$nama','$spesialis','$nip','')";
      $query = mysql_query($sql);
  }
  else if(@$file_type1  !=  "image/gif"  &&  @$file_type1  !=  "image/jpg"  && @$file_type1 != "image/jpeg" && @$file_type1 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../index.php?mod=dokter&pg=form_input_dokter';
        </script> 
        <?php
      } 
  
  else {
      move_uploaded_file($_FILES['photo1']['tmp_name'],$alamatfile1);

      $sql   = "INSERT INTO dokter VALUES('$nip','$nama','$spesialis','$nip','$file_photo1')";
      $query = mysql_query($sql);
   }
      if ($query) {
		  mysql_query("insert into login values ('$nip','$pass','2')");
       ?>
        <script type="text/javascript">
        alert("Data berhasil disimpan");
        document.location="../index.php?mod=dokter&pg=data_dokter";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=dokter&pg=form_input_dokter";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>