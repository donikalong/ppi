
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Dokter</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title" style="text-align:right"><a href="index.php?mod=dokter&pg=form_input_dokter"><button class="btn btn-success m-b-5"> <i class="fa fa-plus"></i> <span>Tambah Data</span> </button></a> </h3>

                            </div>
                            <div class="panel-body">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>NIP Dokter</th>
                                                    <th>Nama</th>
                                                    <th>Spesialis</th>
                                                    <th>Foto</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM dokter");
                                                    $no  = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++; ?></td>
                                                    <td><?php echo $data['iddokter']; ?></td>
                                                    <td><?php echo $data['namadokter']; ?></td>
                                                    <td><?php echo $data['spesialis']; ?></td>
                                                    <td><img src="../photo/dokter/<?php echo $data['foto']; ?>" width="100px" height="130px"></td>
                                                    <td>
                                                        <a href="index.php?mod=dokter&pg=form_edit_dokter&id_dokter=<?php echo $data['iddokter'];?>"><button class="btn btn-icon btn-primary m-b-5"> <i class="fa fa-edit"></i> </button></a>
                                                        <a href="dokter/hapus_dokter.php?id_dokter=<?php echo $data['iddokter'];?>&foto=<?php echo $data['foto'];?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?') ";><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a>                                                       
                                                    </td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           