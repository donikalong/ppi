
            <div class="row cols-wrapper">
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
                <div class="col-md-6">
                                <div class="table-responsive">
									<form method="post" action="page/login/otentikasi.php">
                                    <table class="table table-boxed">
                                        <thead>
                                            <tr>
                                                <th colspan="2"><h2 style="text-align:center;">LOGIN</h2></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td style="text-align:center;">Username</td>
                                                <td><input type="text" class="form-control"  name="username" required></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:center;">Password</td>
                                                <td><input type="password" class="form-control"  name="password" required><i class="fas fa-lock" onclick="show()"></i></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td><input type="submit" class="btn btn-theme" value="Login">
													<input type="reset" class="btn btn-theme" value="Reset"></td>
                                            </tr>
                                        </tbody>
                                    </table><!--//table-->
									</form>
                                </div><!--//table-responsive-->  
                </div>
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
            </div><!--//cols-wrapper-->
