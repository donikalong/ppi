<?php
include('../../inc/config.php');

session_start();
//tangkap data dari form login


@$username	= $_POST['username'];
@$password 	= md5($_POST['password']);

//untuk mencegah sql injection
//kita gunakan mysql_real_escape_string

$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
// query cek
$q = mysql_query("SELECT * from login where username='$username' and password='$password'");

// tampil data
$data = mysql_fetch_array($q);
if(mysql_num_rows($q)==1){
	
	$_SESSION['username']    = $username;
	$_SESSION['password']	 = $data['password'];
	$_SESSION['level']		 = $data['akses'];
	
// kode levelisasi
	if($data["akses"]=="1")
	{ 
	?>
		<script type="text/javascript">
		alert("Selamat Datang <?php echo $username;?>");
	    document.location='../../admin/index.php';
        </script>       
	<?php
	} else if($data["akses"]=="4")
	{ 
	?>
		<script type="text/javascript">
		alert("Selamat Datang ");
	    document.location='../../pasien/index.php';
        </script>       
	<?php
	}else if($data["akses"]=="2")
	{ 
	?>
		<script type="text/javascript">
		alert("Selamat Datang ");
	    document.location='../../dokter/index.php';
        </script>       
	<?php
	} else if($data["akses"]=="3")
	{ 
	?>
		<script type="text/javascript">
		alert("Selamat anda berhasil login");
	    document.location='../../perawat/index.php';
        </script>       
	<?php
	}
	
}
else
{
	?>
	<script type="text/javascript">
		alert("Username atau password salah");
		document.location='../../index.php?mod=page/login&pg=login';
	</script>
    <?php            
}
mysql_close();
?>