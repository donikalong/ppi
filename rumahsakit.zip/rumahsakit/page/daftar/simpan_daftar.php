<?php 
  error_reporting(0);
  date_default_timezone_set('Asia/Jakarta');
  include "../../inc/config.php";

  $email    = $_POST['email'];
  $nama         = $_POST['nama'];
  $alamat = $_POST['alamat'];
  $telpon         = $_POST['telpon'];
  $jk = $_POST['jk'];
  $nobpjs  = $_POST['nobpjs'];
  $pekerjaan   = $_POST['pekerjaan'];
  $ttl   = $_POST['ttl'];
  $tl   = $_POST['tl'];
  $keluhan          = $_POST['keluhan'];
  $username          = $_POST['username'];
  $jd    = $_POST['jd'];
  $password    = md5($_POST['password']);
  $tanggal      = date('Y-m-d');
  
  $sql1         = mysql_query("SELECT idpasien FROM pasien WHERE idpasien='$email'");
  $data1        = mysql_num_rows($sql1);

  $uploaddir    = '../../photo/bpjs/';

  //FOTO1
  $nama_photo1  = $_FILES['photo1']['name'];
  $file_type1   = $_FILES['photo1']['type'];
  $type1        = substr($file_type1,6,4);
                                 
  $datein1      = date("1-YMDHis");
  $alamatfile1  = $uploaddir.$datein1.'.'.$type1;
  $file_photo1  = $datein1.'.'.$type1;

  

  $awal  = date_create($tgl_lahir);
  $akhir = date_create(); // waktu sekarang
  $diff  = date_diff( $awal, $akhir );
  $tahun = $diff->y;

 if ($data1>0){
    ?>
        <script type="text/javascript">
        alert("Email sudah terdaftar");
        document.location='../../index.php?mod=page/daftar&pg=daftar';
                </script> 
        <?php
  }

  else if(@$file_type1  !=  "image/gif"  &&  @$file_type1  !=  "image/jpg"  && @$file_type1 != "image/jpeg" && @$file_type1 != "image/png") {
        // akses denied
        ?>
        <script type="text/javascript">
        alert("Foto Yang Di izinkan Hanya jpg,jpeg,png,gif");
        document.location='../../index.php?mod=page/login&pg=login';
                </script> 
        <?php
      } 
  else {
     
      move_uploaded_file($_FILES['photo1']['tmp_name'],$alamatfile1);

         $sql   = "INSERT INTO pendaftaran VALUES('null','$tanggal','$email','$keluhan')";
		 $sql2   = "INSERT INTO pasien VALUES('$email','$nama','$alamat','$telpon','$nobpjs','$ttl','$tl','$pekerjaan','$jk','$file_photo1','$username')";

  $query = mysql_query($sql);
  $query2 = mysql_query($sql2);
   
  if ($query || $query2){
	  mysql_query("insert into login values ('$username','$password','2')");
    ?>
        <script type="text/javascript">
        alert("Anda Berhasil Mendaftar, silahkan login untuk melihat No Antrian");
        document.location="../../index.php?mod=page/daftar&pg=daftar";
        </script>
    <?php
  }
  else {
        ?>
        <script type="text/javascript">
        alert("Gagal Mendaftar");
        document.location="../../index.php?mod=page/daftar&pg=daftar";
        </script>
    <?php 
  }  
  mysql_close();
}

 ?>