<?php 
  error_reporting(0);
  date_default_timezone_set('Asia/Jakarta');
  include "../../inc/config.php";

  $email      = $_POST['email'];
  $nama       = $_POST['nama'];
  $alamat     = $_POST['alamat'];
  $telpon     = $_POST['telpon'];
  $jk         = $_POST['jk'];
  $agama      = $_POST['agama'];
  $ttl        = $_POST['ttl'];
  $tl         = $_POST['tl'];
  $keluhan    = $_POST['keluhan'];
  $nik        = $_POST['nik'];
  $password   = md5($_POST['password']);
  $tanggal    = date('Y-m-d');
  $asuransi   = $_POST['asuransi'];
  
  $sql1       = mysql_query("SELECT * FROM pasien WHERE nik='$nik'");
  $data1      = mysql_num_rows($sql1);
  $nodaftar   = $_POST['nodaftar'];

     $sql   = "INSERT INTO pendaftaran VALUES('','$tanggal','$nodaftar','$keluhan')";
		 $sql2   = "INSERT INTO pasien VALUES('$nik','$nodaftar','$nama','$jk','$tl','$alamat','$asuransi','$email','$ttl','$email','$agama','$telpon')";

  $query = mysql_query($sql);
  $query2 = mysql_query($sql2);
   
  if ($query || $query2){
	  mysql_query("insert into login values ('$email','$password','4')");
    ?>
        <script type="text/javascript">
        alert("Anda Berhasil Mendaftar, silahkan melakukan login");
        document.location="../../index.php?mod=page/login&pg=login";
        </script>
    <?php
  }
  else {
        ?>
        <script type="text/javascript">
        alert("Gagal Mendaftar");
        document.location="../../index.php?mod=page/daftar&pg=daftarumum";
        </script>
    <?php 
  }  
  mysql_close();


 ?>