<SCRIPT language=Javascript>
//Membuat validasi hanya untuk input angka menggunakan kode javascript
function isNumberKey(evt)
{
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))

return false;
return true;
}
function validAngka(a)
{
	if(!/^[0-9.]+$/.test(a.value))
	{
	a.value = a.value.substring(0,a.value.length-1000);
	}
}
</SCRIPT>

        <div class="container">
            <h2 class="text-center">PENDAFTARAN PASIEN </h2> 
            <div class="box-body table-responsive">

                <form name="form" id="form" method="post" enctype="multipart/form-data" action="page/daftar/simpan_daftarumum.php">
					<table id="example1" class="table table-bordered table-striped">
						<tr>
						<?php
						$sqldaftar	= mysql_query("SELECT * FROM pendaftaran");
						$jmdata 	= mysql_num_rows($sqldaftar);
						$urut 		= date('dmY');
						$nodaftar = $jmdata + 1 ;
						?>
						<td>No Rekam Medis</td><td>: <input name="nodaftar" class="form-control" value="<?php echo $urut ?><?php echo $nodaftar ?>" type="text" readonly> </td>
							
						</tr>
						<tr>
						<td>NIK</td><td>: <input name="nik" id="nik" class="form-control" type="text" size="20" /> </td>
						</tr>
						<tr>
							<td>Email</td><td>: <input name="email" id="email" class="form-control" type="text" size="20" /> </td>
						</tr>
						<tr>
							<td>Nama</td><td>: <input name="nama" id="nama" class="form-control" onkeypress="return event.charCode < 48 || event.charCode  >57" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Alamat</td><td>: <textarea name="alamat" id="alamat" style="width: 100%; height: 100px;" id="alamat" ></textarea> </td>
						</tr>
						<tr>
							<td>Jenis Kelamin</td><td>: 
							                  <input name='jk' type='radio'   id='jk' value='Laki - Laki' size='6' maxlength='10' readonly='readonly' checked='checked' />
        Laki - Laki
        <input name='jk' type='radio' id='jk' value='Perempuan' size='15' maxlength='15' readonly='readonly' />
        Perempuan
						</td>
						</tr>
						<tr>
							<td>Agama<td>: 
							<select name="agama" class="form-control" >
							<option value="ISLAM">ISLAM</option>
							<option value="Kristen">Kristen</option>
							<option value="Hindu">Hindu</option>
							<option value="Budha">Budha</option>
							<option value="Katolik">Katolik</option>
							</select>
							</td>
						</tr>
						<tr>
							<td>Tempat / Tanggal Lahir</td><td>: <input name="ttl" id="ttl" type="text" size="15" />&nbsp;/&nbsp;<input name="tl" id="tl"  type="date" /> </td>
						</tr>
						<tr>
							<td>Telpon</td><td>: <input name="telpon" id="telpon" class="form-control" type="text" size="15" /> </td>
						</tr>
						<tr>
							<td>Asuransi</td><td>: <input name="asuransi" id="asuransi" class="form-control" type="text" size="15" /> </td>
						</tr>
						<tr>
							<td>Password</td><td>: <input name="password" type="password" class="form-control" size="20" /> </td>
						</tr>
						<tr>
							<td>Keluhan</td><td>: <textarea name="keluhan" id="keluhan" style="width: 100%; height: 100px;" id="alamat" ></textarea> </td>
						</tr>
                  		<tr>
     						<td></td><td><input type="submit" name="Simpan" value="Simpan" /></td>
    					</tr>
					</table>
				</form>
            </div><!-- /.box-body -->
        </div>  
       
   