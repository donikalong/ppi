<SCRIPT language=Javascript>
//Membuat validasi hanya untuk input angka menggunakan kode javascript
function isNumberKey(evt)
{
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))

return false;
return true;
}
function validAngka(a)
{
	if(!/^[0-9.]+$/.test(a.value))
	{
	a.value = a.value.substring(0,a.value.length-1000);
	}
}
</SCRIPT>

        <div class="container">
            <h2 class="text-center">PENDAFTARAN PASIEN BPJS</h2> 
            <div class="box-body table-responsive">

                <form name="form" id="form" method="post" enctype="multipart/form-data" action="page/daftar/simpan_daftar.php">
					<table id="example1" class="table table-bordered table-striped">
						<tr>
							<td>Email</td><td>: <input name="email" id="email" class="form-control" type="text" size="20" /> </td>
						</tr>
						<tr>
							<td>Nama</td><td>: <input name="nama" id="nama" class="form-control" onkeypress="return event.charCode < 48 || event.charCode  >57" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Alamat</td><td>: <textarea name="alamat" id="alamat" style="width: 50%; height: 100px;" id="alamat" ></textarea> </td>
						</tr>
						<tr>
							<td>Jenis Kelamin</td><td>: 
							                  <input name='jk' type='radio'   id='jk' value='Laki - Laki' size='6' maxlength='10' readonly='readonly' checked='checked' />
        Laki - Laki
        <input name='jk' type='radio' id='jk' value='Perempuan' size='15' maxlength='15' readonly='readonly' />
        Perempuan
						</td>
						</tr>
						
						<tr>
							<td>Pekerjaan</td><td>: <input name="pekerjaan" id="pekerjaan" class="form-control" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Telpon</td><td>: <input name="telpon" id="telpon" class="form-control" type="text" size="15" /> </td>
						</tr>
                        <tr>
							<td>Tempat / Tanggal Lahir</td><td>: <input name="ttl" id="ttl" type="text" size="15" />&nbsp;/&nbsp;<input name="tl" id="tl"  type="date" /> </td>
						</tr>
                        
						<tr>
							<td>Username</td><td>: <input name="username" id="username" class="form-control" type="text" size="15" /> </td>
						</tr>
						<tr>
							<td>Password</td><td>: <input name="password" type="password" class="form-control" size="20" /> </td>
						</tr>
                        <tr>
							<td>Upload BPJS</td><td>: <input name="photo1" type="file" size="20" /> </td>
						</tr>
                        <tr>
							<td>Keluhan</td><td>: <textarea name="keluhan" id="keluhan" style="width: 50%; height: 100px;" id="alamat" ></textarea> </td>
						</tr>
						<tr>
     						<td></td><td><input type="submit" name="Simpan" value="Simpan" /></td>
    					</tr>
					</table>
				</form>
            </div><!-- /.box-body -->
        </div>  
       
   