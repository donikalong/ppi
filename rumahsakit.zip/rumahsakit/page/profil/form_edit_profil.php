 			<?php  
              $sql   = "SELECT * FROM tbl_sdm,tbl_bagian
                       WHERE tbl_sdm.id_bagian=tbl_bagian.id_bagian
                       AND tbl_sdm.id_sdm='$id_user'";
              $query = mysql_query($sql);
              $data  = mysql_fetch_array($query);  
              $id_bagian            = $data['id_bagian'];
              $nama_bagian          = $data['nama_bagian'];
              $nip                  = $data['nip'];
              $nama                 = $data['nama'];
              $tempat_lahir         = $data['tempat_lahir'];
              $tgl_lahir            = $data['tgl_lahir'];
              $jk                   = $data['jk'];
              $pendidikan_terakhir  = $data['pendidikan_terakhir'];
              $pengalaman_mengajar  = $data['pengalaman_mengajar'];
              $alamat               = $data['alamat'];
              $no_telp              = $data['no_telp'];

              $sql1 = mysql_query("SELECT username FROM tbl_user WHERE id_user='$id_user'");
              $data1= mysql_fetch_assoc($sql1);
              $username = $data1['username'];
            ?>
			<div class="page-intro">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<ol class="breadcrumb">
								<li><i class="fa fa-home pr-10"></i><a href="index.php">Beranda</a></li>
								<li>Daftar</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
			<!-- page-intro end -->

			<!-- main-container start -->
			<!-- ================ -->
			<section class="main-container">

				<div class="container">
					<div class="row">

						<!-- main start -->
						<!-- ================ -->
						<div class="main col-md-2">
						</div>
						<div class="main col-md-8">

							<!-- page-title start -->
							<!-- ================ -->
							<h1 class="page-title text-center">Edit Profil </h1>
							<!-- page-title end -->
							<?php 
								$act = $_GET['act'];
								if ($act==1){

						    ?>
							<div class="alert alert-danger" id="MessageNotSent">
								Password Tidak Sesuai
							</div>
							<?php 
								} else if ($act==2){
							?>
							<div class="alert alert-danger" id="MessageNotSent">
								Email Sudah Terdaftar
							</div>
							<?php 
							} else if ($act==3) {
							?>
							<div class="alert alert-success" id="MessageNotSent">
								Berhasil mendaftar silahkan login
							</div>
							<?php } else if ($act==4) {
							?>
							<div class="alert alert-danger" id="MessageNotSent">
								No KTP sudah terdaftar
							</div>
							<?php } ?>
							<div class="contact-form">
								<form action="page/profil/edit_profil.php" method="POST" enctype="multipart/form-data"> 
									<input type="hidden" class="form-control" name="id_user" required="" value="<?php echo $id_user ?>">

									<div class="form-group has-feedback">
										<label for="nama">NIP</label>
										<input type="text" class="form-control" name="nama" value="<?php echo $nip?>" required="" readonly=""> 
									</div> 
									<div class="form-group has-feedback">
										<label for="nama">Nama Lengkap</label>
										<input type="text" class="form-control" name="nama" value="<?php echo $nama?>" required=""> 
									</div>
									<div class="form-group has-feedback">
										<label for="nama">Tempat Lahir</label>
										<input type="text" class="form-control" name="tempat_lahir" value="<?php echo $tempat_lahir ?>" required=""> 
									</div>
									<div class="form-group has-feedback">
										<label for="nama">Tanggal Lahir</label>
										<input type="text" class="form-control" name="tgl_lahir" value="<?php echo $tgl_lahir ?>" required="" id="datetimepicker5"> 
									</div>
									<div class="form-group has-feedback">
										<label for="nama">Jenis Kelamin</label>
										<select class="form-control" name="jk" required="">
											<?php
												if (empty($jk)){
											?>
											<option value="">--Piih--</option>
											<?php
												} else {
											?>
											<option value="<?php echo $jk?>"><?php echo $jk?></option>
											<?php
												}
											?>
											<option value="Laki-laki">Laki-laki</option>
											<option value="Perempuan">Perempuan</option>
										</select> 
									</div>
									<div class="form-group has-feedback">
										<label for="nama">Pendidikan Terakhir</label>
										<select class="form-control" name="pendidikan_terakhir" required>
                                                <?php
                                                    if (empty($pendidikan_terakhir)){
                                                ?>
                                                <option value="">--Pilih--</option>
                                                <?php
                                                    } else {
                                                ?>
                                                <option value="<?php echo $pendidikan_terakhir ?>"><?php echo $pendidikan_terakhir ?></option>
                                                <?php
                                                    }
                                                ?>
                                                <option value="">--Pilih--</option>
                                                <option value="SMP">SMP</option>
                                                <option value="SMA">SMA</option>
                                                <option value="D1">D1</option>
                                                <option value="D2">D2</option>
                                                <option value="D3">D3</option>
                                                <option value="D4">D4</option>
                                                <option value="S1">S1</option>
                                                <option value="S2">S2</option>
                                                <option value="S3">S3</option>
                                                <option value="Doktor">Doktor</option>
                                                <option value="Profesor">Profesor</option>
                                          </select> 
									</div>  
									<div class="form-group has-feedback">
										<label for="nama">Pengalaman Mengajar</label>
										<textarea class="form-control" name="pengalaman_mengajar"><?php echo $pengalaman_mengajar ?></textarea> 
									</div>  
									<div class="form-group has-feedback">
										<label for="nama">Alamat</label>
										<textarea class="form-control" name="alamat" required=""><?php echo $alamat?></textarea> 
									</div>  
									<div class="form-group has-feedback">
										<label for="nama">No HP</label>
										<input type="number" class="form-control" name="no_telp" value="<?php echo $no_telp?>" required="">  
									</div> 
									 
									<div class="form-group has-feedback">
										<label for="email">Username</label>
										<input type="text" class="form-control" name="username" value="<?php echo $username?>" required=""> 
									</div>
									<div class="form-group has-feedback">
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" value=""> 
									</div>
									<div class="form-group has-feedback">
										<label for="email">Konfirmasi Password</label>
										<input type="password" class="form-control" name="password2" value="">  
									</div>  
									<input type="submit" value="Ubah" class="submit-button btn btn-success"> 
								</form>
							</div>
						</div>
						<!-- main end -->
						<div class="main col-md-2">
						</div>
						

					</div>
				</div>
			</section>
			<!-- main-container end -->