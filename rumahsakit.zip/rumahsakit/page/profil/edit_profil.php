<?php 
  
  include "../../inc/config.php";

  error_reporting(0);
  $id_user              = $_POST['id_user']; 
  $nip                  = $_POST['nip'];
  $nama                 = $_POST['nama'];
  $tempat_lahir         = $_POST['tempat_lahir'];
  $tgl_lahir            = $_POST['tgl_lahir'];
  $jk                   = $_POST['jk'];
  $pendidikan_terakhir  = $_POST['pendidikan_terakhir'];
  $pengalaman_mengajar  = $_POST['pengalaman_mengajar'];
  $alamat               = $_POST['alamat'];
  $no_telp              = $_POST['no_telp'];
  $username             = $_POST['username'];
  $password             = md5($_POST['password']);
  $password2            = md5($_POST['password2']); 
  $pass                 = $_POST['password'];  

  $q = mysql_query("SELECT username FROM tbl_user where username='$username'
       AND id_user!='$id_user'"); 

 if ($password != $password2){
  ?>
        <script type="text/javascript">
        alert("Password tidak sesuai");
        document.location="../../index.php?mod=page/profil&pg=form_edit_profil";
        </script>
    <?php 
 } else if(mysql_num_rows($q)==1){
  ?>
        <script type="text/javascript">
        alert("Username sudah terdaftar");
        document.location="../../index.php?mod=page/profil&pg=form_edit_profil";
        </script>
    <?php 
  }  else {
          
         

          if (empty($pass)){

            $sql0  = mysql_query("UPDATE tbl_user SET nama='$nama',username='$username'
                     WHERE id_user='$id_user'");
 
            $sql   = "UPDATE tbl_sdm SET nama='$nama',tempat_lahir='$tempat_lahir',
                     tgl_lahir='$tgl_lahir',jk='$jk',pendidikan_terakhir='$pendidikan_terakhir',
                     pengalaman_mengajar='$pengalaman_mengajar',alamat='$alamat',no_telp='$no_telp'
                     WHERE id_sdm='$id_user'";
            $query = mysql_query($sql);

          } else {
             $sql0  = mysql_query("UPDATE tbl_user SET nama='$nama',username='$username',password='$password'
             WHERE id_user='$id_user'");


            $sql   = "UPDATE tbl_sdm SET nama='$nama',tempat_lahir='$tempat_lahir',
                     tgl_lahir='$tgl_lahir',jk='$jk',pendidikan_terakhir='$pendidikan_terakhir',
                     pengalaman_mengajar='$pengalaman_mengajar',alamat='$alamat',no_telp='$no_telp'
                     WHERE id_sdm='$id_user'";
            $query = mysql_query($sql);
          }

          

                   
        
  }    

      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Data berhasil diubah");
        document.location="../../index.php?mod=page/profil&pg=profil";
        </script>
      <?php
      }
      else{
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../../index.php?mod=page/profil&pg=profil";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>        }
