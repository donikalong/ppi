            <?php  
              $sql   = "SELECT * FROM tbl_sdm,tbl_bagian
                       WHERE tbl_sdm.id_bagian=tbl_bagian.id_bagian
                       AND tbl_sdm.id_sdm='$id_user'";
              $query = mysql_query($sql);
              $data  = mysql_fetch_array($query);  
              $id_bagian            = $data['id_bagian'];
              $nama_bagian          = $data['nama_bagian'];
              $nip                  = $data['nip'];
              $nama                 = $data['nama'];
              $tempat_lahir         = $data['tempat_lahir'];
              $tgl_lahir            = $data['tgl_lahir'];
              $jk                   = $data['jk'];
              $pendidikan_terakhir  = $data['pendidikan_terakhir'];
              $pengalaman_mengajar  = $data['pengalaman_mengajar'];
              $alamat               = $data['alamat'];
              $no_telp              = $data['no_telp'];

              $sql1 = mysql_query("SELECT username FROM tbl_user WHERE id_user='$id_user'");
              $data1= mysql_fetch_assoc($sql1);
              $username = $data1['username'];
            ?>
            <div class="page-intro">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <ol class="breadcrumb">
                                <li><i class="fa fa-home pr-10"></i><a href="index-2.html">Home</a></li>
                                <li class="active">Profil</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row cols-wrapper">
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
                <div class="col-md-6">
                                <div class="table-responsive">

                                
                                    <form method="post" name="form1" action="page/daftar/simpan_daftar.php" enctype="multipart/form-data">
                                    <table class="table table-boxed">
                                        <thead>
                                            <tr>
                                                <th colspan="3"><h2 style="text-align:center;">Profil Anda</h2></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Bagian</td>
                                                <td>
                                                     <?php echo $nama_bagian ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">NIP</td>
                                                <td width="239"><?php echo $nip?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama</td>
                                                <td><?php echo $nama?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Tempat Lahir</td>
                                                <td> <?php echo $tempat_lahir?> </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Tanggal Lahir</td>
                                                <td> <?php echo $tgl_lahir?> </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Jenis Kelamin</td>
                                                <td>
                                                      <?php echo $jk?> 
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Pendidikan Terakhir</td>
                                                <td>
                                                     <?php echo $pendidikan_terakhir ?> 
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Pengalaman Mengajar</td>
                                                <td> <?php echo $pengalaman_mengajar ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Alamat</td>
                                                <td><?php echo $alamat?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nomor Telepon</td>
                                                <td> <?php echo $no_telp?> </td>
                                            </tr> 
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Username</td>
                                                <td> <?php echo $username?> </td>
                                            </tr> 
                                            <tr style="text-align:center">
                                             
                                                <td colspan="3">
                                                    <a href="?mod=page/profil&pg=form_edit_profil">
                                                        <input type="button" class="btn btn-theme" value="Edit">
                                                    </a>
                                                     </td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                    </form>
                                </div><!--//table-responsive-->  
                </div>
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
            </div><!--//cols-wrapper-->
        