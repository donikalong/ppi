<?php  
  $sql               = mysql_query("SELECT * FROM tbl_masyarakat WHERE id_masyarakat='$id_masyarakat'");
  $data              = mysql_fetch_array($sql);
  $tgl_daftar        = $data['tgl_daftar'];
  $no_ktp            = $data['no_ktp'];
  $nama              = $data['nama'];
  $tempat_lahir      = $data['tempat_lahir'];
  $tgl_lahir         = $data['tgl_lahir'];
  $jk                = $data['jk'];
  $no_telp           = $data['no_telp'];
  $alamat            = $data['alamat']; 
  $email             = $data['email'];
  $ktp               = $data['ktp'];
  $ijazah            = $data['ijazah'];
  $foto              = $data['foto'];
?>
			<div class="page-intro">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<ol class="breadcrumb">
								<li><i class="fa fa-home pr-10"></i><a href="index.php">Beranda</a></li>
								<li>Daftar</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
			<!-- page-intro end -->

			<!-- main-container start -->
			<!-- ================ -->
			<section class="main-container">

				<div class="container">
					<div class="row">

						<!-- main start -->
						<!-- ================ -->
						<div class="main col-md-2">
						</div>
						<div class="main col-md-8">

							<!-- page-title start -->
							<!-- ================ -->
							<h1 class="page-title text-center">Detail Profil </h1>
							
							<div class="contact-form">
								<form action="page/profil/edit_profil.php" method="POST" enctype="multipart/form-data">
									<table border="1" width="100%">
										<tr>
											<td>Tanggal Daftar</td>
											<td>: <?php echo $tgl_daftar?></td>
										</tr> 
										<tr>
											<td>Nama Lengkap</td>
											<td>: <?php echo $nama ?></td>
										</tr>
										<tr>
											<td>Tempat Lahir</td>
											<td>: <?php echo $tempat_lahir ?></td>
										</tr>
										<tr>
											<td>Tgl Lahir</td>
											<td>: <?php echo $tgl_lahir ?></td>
										</tr>
										<tr>
											<td>Jenis Kelamin</td>
											<td>: <?php echo $jk ?></td>
										</tr>
										<tr>
											<td>No Telp</td>
											<td>: <?php echo $no_telp ?></td>
										</tr>
										<tr>
											<td>Alamat</td>
											<td>: <?php echo $alamat ?></td>
										</tr>
										  
										<tr>
											<td>Email</td>
											<td>: <?php echo $email ?></td>
										</tr>
										 
										

									</table>
									
								</form>
							</div>
						</div>
						<!-- main end -->
						<div class="main col-md-2">
						</div>
						

					</div>
				</div>
			</section>
			<!-- main-container end -->