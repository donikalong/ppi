
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Tata Cara Pendaftaran</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="index-2.html">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Events</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row page-row">
                        <div class="events-wrapper col-md-8 col-sm-7"> 
                            <?php 
                                $sql1 = mysql_query("SELECT * FROM tbl_infopendaftaran");
                                while ($data1=mysql_fetch_array($sql1)) {
                            ?>                        
                            <article class="events-item page-row has-divider clearfix">
                                <div class="date-label-wrapper col-md-1 col-sm-2">
                                    <p class="date-label">
                                        <span class="month">&nbsp;</span>
                                        <span class="date-number">1</span>
                                    </p>
                                </div><!--//date-label-wrapper-->
                                <div class="details col-md-11 col-sm-10">
                                    <h3 class="title">Pendaftaran</h3>
                                    <!--<p class="meta"><span class="time"><i class="fa fa-clock-o"></i>10:00am - 18:00pm</span><span class="location"><i class="fa fa-map-marker"></i><a href="#">East Campus</a></span></p> -->  
                                    <p class="desc"><?php echo $data1['infopendaftaran']; ?></p>                       
                                </div><!--//details-->
                            </article><!--//events-item-->
                            <?php } ?>
                            
                        </div>

                        <div class="events-wrapper col-md-8 col-sm-7"> 
                            <?php 
                                $sql2 = mysql_query("SELECT * FROM tbl_syaratpendaftaran");
                                while ($data2=mysql_fetch_array($sql2)) {
                            ?>                        
                            <article class="events-item page-row has-divider clearfix">
                                <div class="date-label-wrapper col-md-1 col-sm-2">
                                    <p class="date-label">
                                        <span class="month">&nbsp;</span>
                                        <span class="date-number">2</span>
                                    </p>
                                </div><!--//date-label-wrapper-->
                                <div class="details col-md-11 col-sm-10">
                                    <h3 class="title">Syarat Pendaftaran</h3>
                                    <!--<p class="meta"><span class="time"><i class="fa fa-clock-o"></i>10:00am - 18:00pm</span><span class="location"><i class="fa fa-map-marker"></i><a href="#">East Campus</a></span></p> -->  
                                    <p class="desc"><?php echo $data2['syaratpendaftaran']; ?></p>                       
                                </div><!--//details-->
                            </article><!--//events-item-->
                            <?php } ?>
                            
                        </div>
                            <!--
                          <div class="events-wrapper col-md-8 col-sm-7">                                                  
                            <article class="events-item page-row has-divider clearfix">
                                <div class="date-label-wrapper col-md-1 col-sm-2">
                                    <p class="date-label">
                                        <span class="month">&nbsp;</span>
                                        <span class="date-number">3</span>
                                    </p>
                                </div> 
                                <div class="details col-md-11 col-sm-10">
                                    <h3 class="title">Rincian Biaya</h3>  
                                    <p class="desc">
                                        <table border="1" width="70%">
                                            <tr style="font-weight:bold">
                                                <td width="10%" align="center">No</td>
                                                <td width="30%" align="center">Uraian</td>
                                                <td width="30%" align="center">Biaya</td>
                                                <td width="30%" align="center">Keterangan</td>
                                            </tr>
                                            <?php 
                                                $sql3 = mysql_query("SELECT * FROM tbl_smp");
                                                $no = 1;
                                                while ($data3=mysql_fetch_array($sql3)) {
                                            ?>
                                            <tr>
                                                <td align="center"><?php echo $no++; ?></td>
                                                <td><?php echo $data3['uraian']; ?></td>
                                                <td align="center"><?php echo "Rp. ".number_format($data3['biaya']); ?></td>
                                                <td><?php echo $data3['keterangan']; ?></td>
                                            </tr>
                                            <?php } ?>
                                        </table>
                                    </p>                       
                                </div> 
                            </article>                            
                        </div>
                        -->
                        

                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page--> 
 
 