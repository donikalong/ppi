
        <div class="container">
            <h2 class="text-center">Daftar Siswa Yang Tidak Diterima</h2>
            <h2 class="text-center">SMP Negri 1 Sekampung Udik</h2>
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No Pendaftaran</th>
                            <th>NISN</th>
                            <th>Nama</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Tanggal Daftar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $sql = mysql_query("SELECT * FROM tbl_daftar WHERE jenjang='SMP'
                                   AND status='ditolak'");
                            while ($data=mysql_fetch_array($sql)) {
                        ?>
                        <tr>
                            <td><?php echo $data['id_daftar']; ?></td>
                            <td><?php echo $data['nisn']; ?></td>
                            <td><?php echo $data['nama']; ?></td>
                            <td><?php echo $data['tgl_lahir']; ?></td>
                            <td><?php echo $data['jenis_kelamin']; ?></td>
                            <td><?php echo $data['tanggal']; ?></td>
                            <td><a href="index.php?mod=page/terdaftar&pg=rincian_smp&id_daftar=<?php echo $data['id_daftar']?>"><input type="button" class="btn btn-theme" value="Lihat Rincian"></td>
                        </tr>
                        <?php } ?>
                </table>
            </div><!-- /.box-body -->
        </div>  
       
   