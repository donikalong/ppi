<link rel="stylesheet" type="text/css" href="assets/front-end/css/jquery.datetimepicker.css"/>
            <div class="row cols-wrapper">
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
                <div class="col-md-6">
                                <div class="table-responsive">

                                <?php 
                                    $id_daftar = $_GET['id_daftar'];
                                    $sql = mysql_query("SELECT * FROM tbl_daftar 
                                           WHERE id_daftar='$id_daftar'");
                                    $data = mysql_fetch_assoc($sql);
                                ?>
									<form method="post" name="form1" action="page/daftar/simpan_daftar.php" enctype="multipart/form-data">
                                    <table class="table table-boxed">
                                        <thead>
                                            <tr>
                                                <th colspan="3"><h2 style="text-align:center;">Rincian Pendaftar</h2></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">No Pendaftaran</td>
                                                <td width="239"><input type="text" class="form-control" value="<?php echo $data['id_daftar'];?>" name="id_daftar" readonly="" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Jenjang Pendaftaran</td>
                                                <td>
                                                     <input type="text" class="form-control" value="<?php echo $data['jenjang'];?>" name="id_daftar" readonly="" readonly>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama Calon Siswa</td>
                                                <td width="239"><input type="text" class="form-control"  name="nama" readonly value="<?php echo $data['nama'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">NISN</td>
                                                <td><input type="text" class="form-control"  name="nisn" readonly value="<?php echo $data['nisn'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Tempat Lahir</td>
                                                <td><input type="text" class="form-control"  name="tempat_lahir" value="<?php echo $data['tempat_lahir'];?>" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Tanggal Lahir</td>
                                                <td><input type="text" class="form-control"  name="tgl_lahir" id="datetimepicker1" value="<?php echo $data['tgl_lahir'];?>" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Jenis Kelamin</td>
                                                <td>
                                                     <input type="text" class="form-control"  name="jenis_kelamin" id="datetimepicker1" value="<?php echo $data['jenis_kelamin'];?>" readonly>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Agama</td>
                                                <td>
                                                    <input type="text" class="form-control"  name="tgl_lahir" id="datetimepicker1" value="<?php echo $data['agama'];?>" readonly>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama Orang Tua</td>
                                                <td><input type="text" class="form-control"  name="nama_orangtua" readonly value="<?php echo $data['nama_orangtua'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Alamat Calon Siswa</td>
                                                <td><textarea id="message" class="form-control" rows="4" name="alamat_siswa" readonly=""><?php echo $data['alamat_siswa'];?></textarea></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nomor Telepon</td>
                                                <td><input type="text" class="form-control"  name="telp" readonly value="<?php echo $data['telp'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Asal Sekolah</td>
                                                <td><input type="text" class="form-control"  name="asal_sekolah" value="<?php echo $data['asal_sekolah'];?>" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Data Nilai SKHU/IJAZAH</td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td width="30" align="center" style="text-align:right;">a.</td>
                                                <td width="138">Bahasa Indonesia</td>
                                                <td><input type="text" class="form-control"  name="b_indonesia" value="<?php echo $data['b_indonesia'];?>" id="b_indonesia" readonly></td>
                                            </tr>
                                            <tr>
                                                <td align="center" style="text-align:right;">b</td>
                                                <td>Matematika</td>
                                                <td><input type="text" class="form-control"  name="matematika" value="<?php echo $data['matematika'];?>" id="b_matematika" readonly></td>
                                            </tr>
                                            <tr>
                                                <td align="center" style="text-align:right;">c.</td>
                                                <td>IPA</td>
                                                <td><input type="text" class="form-control"  name="ipa" id="ipa" readonly value="<?php echo $data['ipa'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td align="center" style="text-align:right;">d.</td>
                                                <td>Bahasa Inggris</td>
                                                <td><input type="text" class="form-control"  name="b_inggris" id="b_inggris" value="<?php echo $data['b_inggris'];?>" onkeyup="hitung();" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Rata-Rata 4 Mata Pelajaran</td>
                                                <td><input type="text" class="form-control"  name="rata_rata" id="rata_rata" value="<?php echo $data['rata_rata'];?>" readonly="" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Piagam Penghargaan</td>
                                                <td><textarea id="message" class="form-control" rows="4" name="piagam" readonly=""><?php echo $data['piagam']?></textarea></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Mengetahui Orang Tua/Wali</td>
                                                <td><input type="text" class="form-control"  name="mengetahui" readonly value="<?php echo $data['mengetahui'];?>"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Tanggal Daftar</td>
                                                <td><input type="text" class="form-control"  name="tanggal" value="<?php echo $data['tanggal'];?>" readonly="" readonly></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Foto</td>
                                                <td><a href="photo/<?php echo $data['photo1']?>"><img src="photo/<?php echo $data['photo1']?>" width="130px" height="170px"></a></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Scan Ijazah </td>
                                                <td><a href="photo/lampiran/<?php echo $data['file']?>" target="_blank"><img src="photo/lampiran/<?php echo $data['file']?>" width="130px" height="170px"></a></td>
                                            </tr>
                                            <tr>
                                                <?php 
                                                    $stat = $_GET['stat'];
                                                    if ($stat==1){
                                                ?>
                                                    <td colspan="3" style="text-align:center;color:green">Selamat anda berhasil mendaftar</td>
                                                <?php
                                                    }else{
                                                ?>
                                                    <td colspan="3" style="text-align:center;color:red">Pastikan data yang anda inputkan sudah benar, format foto hanya berupa (jpg, png, jpeg) dan format lampiran hanya berupa(xls, xlsx, doc, dox, pdf)</td>
                                                <?php
                                                    }
                                                ?>
                                                
                                            </tr>
                                            
                                        </tbody>
                                    </table>
									</form>
                                </div><!--//table-responsive-->  
                </div>
                <div class="col-md-3">
                    
                </div><!--//col-md-3-->
            </div><!--//cols-wrapper-->

            <script type="text/javascript">    
           
      function hitung(){

              

              b_indonesia   = eval(form1.b_indonesia.value);
              matematika    = eval(form1.matematika.value);
              ipa           = eval(form1.ipa.value);
              b_inggris     = eval(form1.b_inggris.value);

              if (isNaN(b_indonesia))
                b_indonesia = 0;
              if (isNaN(matematika))
                matematika = 0;
              if (isNaN(ipa))
                ipa = 0;
              if (isNaN(b_inggris))
                b_inggris = 0;

              rata_rata     = (b_inggris + matematika + ipa + b_inggris) / 4;
              form1.rata_rata.value = rata_rata;
          
            }
          </script>
    <script src="assets/front-end/js/jquery.js"></script>
    <script src="assets/front-end/js/jquery.datetimepicker.full.js"></script>
    <script>
            $('#datetimepicker1').datetimepicker({format:'Y-m-d',timepicker:false});

  
    </script>
          