
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Visi dan Misi</h1>
                 
                </header> 
                <div class="page-content">
                    <div class="row page-row">
                        <article class="welcome col-md-8 col-sm-7">      
                            <blockquote class="custom-quote"><strong>Visi</strong>
                              <p>                </p>
                              <p><strong>Misi</strong></p>
                              <p>&nbsp;</p>
                              <p><strong>M</strong><strong>OTTO</strong></p>
                              <p>                MELAYANI DENGAN SEPENUH HATI </p>
                      </blockquote></article>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page--> 
