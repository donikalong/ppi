  <?php 

    include "../../inc/config.php";

    $id_pendaftaran  		= $_GET['id_pendaftaran'];   
    $sql   = "DELETE FROM tbl_pendaftaran WHERE id_pendaftaran='$id_pendaftaran'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../../index.php?mod=page/mendaftar&pg=mendaftar'</script>";
 ?>