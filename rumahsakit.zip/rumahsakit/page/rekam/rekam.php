
        <div class="page-intro">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <ol class="breadcrumb">
                                <li><i class="fa fa-home pr-10"></i><a href="index-2.html">Home</a></li>
                                <li class="active">Riwayat Pemeriksaan</li>
                            </ol>
                        </div>
                    </div>
                </div>
        </div>
        <div class="container">
            <h2 class="text-center"><i class="fa fa-calendar"></i> Daftar Rekam Medis</h2> 
            <?php
                                if (!empty($catatan)){
                            ?>
                 <div class="alert alert-warning" id="MessageNotSent">
                CATATAN: <?php echo $catatan ?>
              </div>      
              <?php
                }
              ?>      
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Pendaftaran</th>
                                                    <th>Tanggal</th>
                                                    <th>Email</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>No BPJS</th>
                                                    <th>Pekerjaan</th>
                                                    <th>Diagnosa</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
												$user = $_SESSION['username'];
                                            		$sql = mysql_query("SELECT * FROM pasien inner join pendaftaran on pasien.idpasien = pendaftaran.idpasien inner join rekammedis on pendaftaran.nopendaftaran = rekammedis.nopendaftaran where pasien.username='$user' ORDER BY rekammedis.tanggal DESC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['nopendaftaran'] ?></td>
                                                    <td><?php echo $data['tanggal'] ?></td>
                                                    <td><?php echo $data['idpasien'] ?></td>
                                                    <td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                    <td><?php echo $data['nobpjs'] ?></td>
                                                    <td><?php echo $data['pekerjaan'] ?></td>
                                                    <td><?php echo $data['diagnosa'] ?></td>
                                                    <td>
                                                           
                                                       <a href="index.php?mod=page/rekam&pg=obat&id_rekam=<?php echo $data['norekam'];?>"><button class="btn btn-icon btn-info m-b-5"> <i class="fa fa-eye">Resep Obat</i> </button></a>
             </td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
            </div><!-- /.box-body -->
        </div>  
       
   