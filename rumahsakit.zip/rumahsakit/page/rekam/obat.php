
        <div class="page-intro">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <ol class="breadcrumb">
                                <li><i class="fa fa-home pr-10"></i><a href="index-2.html">Home</a></li>
                                <li class="active">Resep Obat</li>
                            </ol>
                        </div>
                    </div>
                </div>
        </div>
        <div class="container">
            <h2 class="text-center"><i class="fa fa-calendar"></i> Resep Obat</h2> 
            <?php
                                if (!empty($catatan)){
                            ?>
                 <div class="alert alert-warning" id="MessageNotSent">
                CATATAN: <?php echo $catatan ?>
              </div>      
              <?php
                }
              ?>      
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Obat</th>
                                                    <th>Aturan Pakai</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
												$user = $_SESSION['username'];
												$idrekam = $_GET['id_rekam'];
                                            		$sql = mysql_query("SELECT * FROM detailresep inner join obat on detailresep.kodeobat = obat.kodeobat where detailresep.noresep='$idrekam' ");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['namaobat'] ?></td>
                                                    <td><?php echo $data['jumlah'] ?></td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
            </div><!-- /.box-body -->
        </div>  
       
   