<?php 
  error_reporting(0);
  date_default_timezone_set('Asia/Jakarta');
  include "../../inc/config.php";

  $iduser      = $_POST['email'];
  $kodepaket        = $_POST['kode'];
  $tanggal     = date('Y-m-d');
  $jadwal = $_POST['jd'];

   

  $sql   = "INSERT INTO pendaftaran VALUES(null,'$tanggal','$iduser','$kodepaket','$jadwal',
           'Proses','1')";
  $query = mysql_query($sql);
  
   
  if ($query){
    ?>
        <script type="text/javascript">
        alert("Anda Berhasil Mendaftar");
        document.location="../../index.php";
        </script>
    <?php
  }
  else {
        ?>
        <script type="text/javascript">
        alert("Anda Gagal Mendaftar");
        document.location="../../index.php?mod=page/mendaftar&pg=daftar";
        </script>
    <?php 
  }  
  mysql_close();


 ?>