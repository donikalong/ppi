<SCRIPT language=Javascript>
//Membuat validasi hanya untuk input angka menggunakan kode javascript
function isNumberKey(evt)
{
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))

return false;
return true;
}
function validAngka(a)
{
	if(!/^[0-9.]+$/.test(a.value))
	{
	a.value = a.value.substring(0,a.value.length-1000);
	}
}
</SCRIPT>

        <div class="container">
            <h2 class="text-center">PENDAFTARAN</h2> 
            <div class="box-body table-responsive">
				<?php
				$kodepaket = $_GET['kodepaket'];
				$sql = mysql_query("select * from paket where kodepaket='$kodepaket'");
				$data = mysql_fetch_array($sql);
				?>
                <form name="form" id="form" method="post" enctype="multipart/form-data" action="page/mendaftar/simpan_mendaftar.php">
					<table id="example1" class="table table-bordered table-striped">
						<tr>
							<td>Nama Paket</td><td>: 
                            <input name="kode" type="hidden" value="<?php echo $kodepaket ?>" />
                            <input name="email" type="hidden" value="<?php echo $_SESSION['username'] ?>" />
                            <input name="nama" id="nama" class="form-control"  value="<?php echo $data['namapaket'] ?>" readonly="readonly" /> 
                            </td>
						</tr>
						
						<tr>
							<td>Harga</td><td>:  <input name="nama" id="nama" class="form-control"  value="<?php echo $data['harga'] ?>" readonly="readonly" />  </td>
						</tr>
							<tr>
							<td>Jadwal</td><td>: 
                            
							<?php 
							$sql2 = mysql_query( "select kodejadwal, jadwal as jd from jadwal order by kodejadwal asc");
							while ($data3 = mysql_fetch_array($sql2)){
							?>
                            <input name="jd" type="radio" value="<?php echo $data3 ['kodejadwal'] ?>" /><?php echo $data3 ['jd'] ?>
                            <?php } ?> 
                          </td>						</tr>
						<tr>
     						<td></td><td><input type="submit" name="Simpan" value="Simpan" /></td>
    					</tr>
					</table>
				</form>
            </div><!-- /.box-body -->
        </div>  
       
   