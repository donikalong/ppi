-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 01 Jan 2023 pada 13.10
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbppi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dekubitus`
--

CREATE TABLE IF NOT EXISTS `dekubitus` (
  `iddekubitus` int(10) NOT NULL,
  `kondisi` varchar(20) NOT NULL,
  `mental` varchar(20) NOT NULL,
  `aktifitas` varchar(25) NOT NULL,
  `mobilitas` varchar(25) NOT NULL,
  `inkontinensia` varchar(25) NOT NULL,
  `idrawat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dekubitus`
--

INSERT INTO `dekubitus` (`iddekubitus`, `kondisi`, `mental`, `aktifitas`, `mobilitas`, `inkontinensia`, `idrawat`) VALUES
(4, 'Baik', 'Apatis', 'Jalan Sendiri', 'Agak Terbatas', 'Kontinen', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
  `iddokter` varchar(20) NOT NULL,
  `namadokter` varchar(25) NOT NULL,
  `spesialis` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dokter`
--

INSERT INTO `dokter` (`iddokter`, `namadokter`, `spesialis`, `username`, `foto`) VALUES
('123456', 'Dr. Cristian', 'Anak', '123456', '1-2022DecThu074759.jpeg'),
('1656546545', 'Dr. Kevin', 'Penyakit Dalam', '1656546545', '1-2022DecSat183515.jpeg'),
('245456565621', 'Dr. Shofia', 'Saraf', '245456565621', '1-2022DecSat183724.jpeg'),
('346566565', 'Dr. Erwin', 'Jantung', '346566565', '1-2022DecSat183215.jpeg'),
('65545454565', 'Dr. Siska', 'Kandungan', '65545454565', '1-2022DecSat183548.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `isk`
--

CREATE TABLE IF NOT EXISTS `isk` (
  `idisk` int(10) NOT NULL,
  `jp` varchar(20) NOT NULL,
  `pemeriksaan` varchar(20) NOT NULL,
  `tglpemeriksaan` date NOT NULL,
  `keterangan` text NOT NULL,
  `tglpasang` date NOT NULL,
  `sesuaidc` varchar(6) NOT NULL,
  `handhyglen` varchar(6) NOT NULL,
  `plester` varchar(6) NOT NULL,
  `adp` varchar(6) NOT NULL,
  `steril` varchar(6) NOT NULL,
  `lepasindikasi` varchar(6) NOT NULL,
  `balon` varchar(6) NOT NULL,
  `bagurine` varchar(6) NOT NULL,
  `idrawat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `isk`
--

INSERT INTO `isk` (`idisk`, `jp`, `pemeriksaan`, `tglpemeriksaan`, `keterangan`, `tglpasang`, `sesuaidc`, `handhyglen`, `plester`, `adp`, `steril`, `lepasindikasi`, `balon`, `bagurine`, `idrawat`) VALUES
(3, 'Dauer', 'Urine', '2023-01-02', 'Pemeriksaan ISK', '2023-01-03', 'Ya', 'Ya', 'Tidak', 'Ya', 'Ya', 'Ya', 'Tidak', 'Ya', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(20) NOT NULL,
  `password` text NOT NULL,
  `akses` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`, `akses`) VALUES
('123456', 'e10adc3949ba59abbe56e057f20f883e', 2),
('1656546545', '0dccd76bc207baf05914a751447551b9', 2),
('245456565621', '14edeba7d14647a6c1797dd7abb62d3c', 2),
('346566565', '3537e6df58cf734586c26c5b05bfecf3', 2),
('3541013541', '5cb5b13e87253c3c250300de0724be4a', 3),
('654321', 'c33367701511b4f6020ec61ded352059', 3),
('65545454565', 'c5e4cc025240549efd9839d1c28efccb', 2),
('82355546565', '581d99bbd0a47a636cd3bf3ed6fd7211', 3),
('admin', '202cb962ac59075b964b07152d234b70', 1),
('aska@gmail.com', '202cb962ac59075b964b07152d234b70', 4),
('fajarrohmad869@gmail', '202cb962ac59075b964b07152d234b70', 4),
('kaesang@gmail.com', '202cb962ac59075b964b07152d234b70', 4),
('khaira@gmail.com', '202cb962ac59075b964b07152d234b70', 4),
('satria@gmail.com', '202cb962ac59075b964b07152d234b70', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `nik` varchar(20) NOT NULL,
  `norm` varchar(15) NOT NULL,
  `namapasien` varchar(50) NOT NULL,
  `jk` varchar(15) NOT NULL,
  `tl` date NOT NULL,
  `alamat` text NOT NULL,
  `asuransi` varchar(25) NOT NULL,
  `username` varchar(20) NOT NULL,
  `tempat` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `telpon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`nik`, `norm`, `namapasien`, `jk`, `tl`, `alamat`, `asuransi`, `username`, `tempat`, `email`, `agama`, `telpon`) VALUES
('123456789', '301220221', 'khaira', 'Perempuan', '2022-02-02', 'Bandar Lampung', 'BPJS', 'khaira@gmail.com', 'Lampung', 'khaira@gmail.com', 'ISLAM', '082182796396'),
('35465126542326', '311220223', 'fajar', 'Laki - Laki', '2015-06-16', 'Lampung', 'Sinarmas', 'fajarrohmad869@gmail', 'Lampung', 'fajarrohmad869@gmail.com', 'ISLAM', '082182796396'),
('544656565799654', '311220222', 'satria', 'Laki - Laki', '2002-02-05', 'Palembang', 'Sinarmas', 'satria@gmail.com', 'Palembang', 'satria@gmail.com', 'ISLAM', '082182796396'),
('546546545454', '311220224', 'Aska', 'Laki - Laki', '2012-06-20', 'Palembang', 'BPJS', 'aska@gmail.com', 'Palembang', 'aska@gmail.com', 'Kristen', '08980861085'),
('79542323232323', '010120235', 'Kaesang', 'Laki - Laki', '0000-00-00', 'Palembang', 'BPJS', 'kaesang@gmail.com', 'Palembang', 'kaesang@gmail.com', 'ISLAM', '083112122');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran`
--

CREATE TABLE IF NOT EXISTS `pendaftaran` (
`idpendaftaran` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `norm` varchar(20) NOT NULL,
  `keluhan` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendaftaran`
--

INSERT INTO `pendaftaran` (`idpendaftaran`, `tanggal`, `norm`, `keluhan`) VALUES
(1, '2022-12-30', '301220221', 'Gatal Gatal di tangan'),
(2, '2023-01-01', '311220222', 'Pusing'),
(3, '2023-01-01', '311220223', 'Sakit Buang Air Kecil'),
(4, '2023-01-01', '311220224', 'Sesak Nafas'),
(5, '2023-01-01', '010120235', 'Sakit Kepala');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perawat`
--

CREATE TABLE IF NOT EXISTS `perawat` (
  `idperawat` varchar(20) NOT NULL,
  `namaperawat` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `telpon` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `perawat`
--

INSERT INTO `perawat` (`idperawat`, `namaperawat`, `alamat`, `telpon`, `username`, `foto`) VALUES
('3541013541', 'Venny', 'Lampung', '085455265454', '3541013541', '1-2022DecSat183913.jpeg'),
('654321', 'Dea', 'Karang Anyar', '082182796396', '654321', '1-2022DecThu114855.jpeg'),
('82355546565', 'Aisah', 'Lampung', '0895546554656', '82355546565', '1-2022DecSat184002.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `phlebitis`
--

CREATE TABLE IF NOT EXISTS `phlebitis` (
  `idphilebitis` int(10) NOT NULL,
  `jp` varchar(20) NOT NULL,
  `tp` varchar(20) NOT NULL,
  `keterangan` text NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tglpasang` date NOT NULL,
  `kebersihan` varchar(6) NOT NULL,
  `cekbalutan` varchar(6) NOT NULL,
  `cektempat` varchar(6) NOT NULL,
  `tgllepas` date NOT NULL,
  `lepaskeluhan` varchar(6) NOT NULL,
  `lepasjam` varchar(6) NOT NULL,
  `idrawat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `phlebitis`
--

INSERT INTO `phlebitis` (`idphilebitis`, `jp`, `tp`, `keterangan`, `lokasi`, `tglpasang`, `kebersihan`, `cekbalutan`, `cektempat`, `tgllepas`, `lepaskeluhan`, `lepasjam`, `idrawat`) VALUES
(2, 'Kateter V Perifer', 'Transfusi', 'Pemeriksaan Phlebitis', 'Tangan Kiri', '2023-01-05', 'Ya', 'Tidak', 'Ya', '2023-01-27', 'Ya', 'Ya', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rawat`
--

CREATE TABLE IF NOT EXISTS `rawat` (
  `idrawat` int(10) NOT NULL,
  `tglmasuk` date NOT NULL,
  `idpendaftaran` int(10) NOT NULL,
  `iddokter` varchar(20) NOT NULL,
  `idruangan` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  `infeksi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rawat`
--

INSERT INTO `rawat` (`idrawat`, `tglmasuk`, `idpendaftaran`, `iddokter`, `idruangan`, `status`, `infeksi`) VALUES
(1, '2022-12-31', 1, '123456', 'A1', 'Rawat', 'Scables'),
(2, '2022-12-31', 2, '65545454565', 'A2', 'Rawat', 'Phlebitis'),
(3, '2022-12-31', 3, '346566565', 'M1', 'Rawat', 'ISK'),
(4, '2022-12-31', 4, '65545454565', 'R1', 'Rawat', 'Dekubitus');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruangan`
--

CREATE TABLE IF NOT EXISTS `ruangan` (
  `idruangan` varchar(10) NOT NULL,
  `namaruangan` varchar(25) NOT NULL,
  `kelas` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ruangan`
--

INSERT INTO `ruangan` (`idruangan`, `namaruangan`, `kelas`) VALUES
('A1', 'Anyelir', 'II'),
('A2', 'Anggrek', 'II'),
('M1', 'Mawar', 'I'),
('R1', 'Rose', 'III');

-- --------------------------------------------------------

--
-- Struktur dari tabel `scables`
--

CREATE TABLE IF NOT EXISTS `scables` (
  `idscables` int(10) NOT NULL,
  `kebersihan` varchar(20) NOT NULL,
  `alatpribadi` varchar(20) NOT NULL,
  `lingkungan` varchar(20) NOT NULL,
  `tglpemeriksaan` date NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `presentase` varchar(6) NOT NULL,
  `idrawat` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `scables`
--

INSERT INTO `scables` (`idscables`, `kebersihan`, `alatpribadi`, `lingkungan`, `tglpemeriksaan`, `lokasi`, `presentase`, `idrawat`) VALUES
(1, 'Sangat Bersih', 'Bersama', 'Kumuh', '2022-12-31', 'Badan', '35', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dekubitus`
--
ALTER TABLE `dekubitus`
 ADD PRIMARY KEY (`iddekubitus`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
 ADD PRIMARY KEY (`iddokter`);

--
-- Indexes for table `isk`
--
ALTER TABLE `isk`
 ADD PRIMARY KEY (`idisk`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
 ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
 ADD PRIMARY KEY (`idpendaftaran`);

--
-- Indexes for table `perawat`
--
ALTER TABLE `perawat`
 ADD PRIMARY KEY (`idperawat`);

--
-- Indexes for table `phlebitis`
--
ALTER TABLE `phlebitis`
 ADD PRIMARY KEY (`idphilebitis`);

--
-- Indexes for table `rawat`
--
ALTER TABLE `rawat`
 ADD PRIMARY KEY (`idrawat`);

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
 ADD PRIMARY KEY (`idruangan`);

--
-- Indexes for table `scables`
--
ALTER TABLE `scables`
 ADD PRIMARY KEY (`idscables`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
MODIFY `idpendaftaran` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
