<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php 
include "../../inc/config.php";
$dari_tanggal        = $_GET['dari_tanggal']; 
$sampai_tanggal      = $_GET['sampai_tanggal']; 
                              
?>
<body onload="window.print() ">
<table width="100%" border="0">
  <tr>
    <td width="15%" rowspan="3"><img src="../../assets/front-end/images/logo2.png" width="70%" height="60%" /></td>
    <td width="70%">&nbsp;</td>
    <td width="15%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"><h2>KLINIK DOKTER ROSDIANA<br /></h2>
    <strong>Alamat: J<span class="adr clearfix col-md-12 col-sm-4"><span class="adr-group pull-left"><span class="street-address">l.</span> Alimudin Umar No. 163, Campang Raya,</span><span class="adr-group pull-left">Tanjung Karang Timur<br />
    <span class="country-name">Kota Bandar Lampung</span> </span></span></strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"> <hr size="3" color="#000000"/> </td>
  </tr>
  <tr>
    <td colspan="3" align="center"><strong>Laporan Pasien
    <?php
    	if (!empty($dari_tanggal)){
			echo "Dari Tanggal ".$dari_tanggal." - Sampai Tanggal ".$sampai_tanggal; 
		}
	?>
     <br />
      <br />
    </strong></td>
  </tr>
  <tr>
    <td colspan="3"><table width="100%" border="1" cellpadding="0" cellspacing="0">
     <thead>
                                                <tr>
                                                  <th>No</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat </th>
                                                    <th>Telpon</th>
                                                    <th>Tanggal Berobat</th>
                                                    <th>Diagnosa Penyakit</th  
                                                ></tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
                                                    if (empty($dari_tanggal)){
                                                 $sql = mysql_query("SELECT * FROM rekammedis inner join pendaftaran on rekammedis.nopendaftaran = pendaftaran.nopendaftaran inner join pasien on pendaftaran.idpasien = pasien.idpasien");
                                                    } else {
                                                     $sql = mysql_query("SELECT * FROM rekammedis inner join pendaftaran on rekammedis.nopendaftaran = pendaftaran.nopendaftaran inner join pasien on pendaftaran.idpasien = pasien.idpasien
                                                            WHERE rekammedis.tanggal 
                                                            BETWEEN '$dari_tanggal' 
                                                            AND '$sampai_tanggal'");   
                                                    }
                                                    $no  = 1; 
                                                    while($data = mysql_fetch_array($sql)){
                                              $namapasien           = $data['namapasien'];
                                                          $alamat          = $data['alamat'];
                                                          $telpon        = $data['telpon'];
                                                          $tanggal       = $data['tanggal'];
                                                          $diagnosa                  = $data['diagnosa'];
    
                                                      
                                                ?>
                                                <tr>
                                                    <td><?php echo $no++ ?></td>
                                                    <td><?php echo $namapasien ?></td>
                                                    <td><?php echo $alamat ?></td>
                                                    <td><?php echo $telpon ?></td>
                                                    <td><?php echo $tanggal ?></td>
                                                    <td><?php echo $diagnosa ?></td>
                                                       </tr>
                                                    
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><table width="100%" border="0">
      <tr>
        <td width="79%">&nbsp;</td>
        <td width="21%">Bandarlampung, <?php echo date('Y-m-d');?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><strong>Dokter</strong></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>