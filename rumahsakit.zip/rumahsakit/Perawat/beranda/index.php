

			 <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Selamat Datang</h3> 
                </div>
                 <?php
				$user = $_SESSION['username'];
				$ml = mysql_query("select * from perawat where idperawat='$user'");
				$kj = mysql_fetch_array($ml);
				?>
                <table border="0" width="100%">
                <tr>
                <td colspan="2"  align="center"><img src="../photo/perawat/<?php echo $kj['foto'] ?>" width="30%" /></td>
                
                </tr>
                <tr>
                <td colspan="2"</td>
                </tr>
                <tr>
                <td width="20%">NIP</td>
                <td>: <strong><?php echo $kj['idperawat'] ?></strong></td>
                </tr>
                
                <tr>
                <td width="20%">Nama Petugas</td>
                <td>: <strong><?php echo $kj['namaperawat'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Alamat</td>
                <td>: <strong><?php echo $kj['alamat'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Telpon</td>
                <td>: <strong> <?php echo $kj['telpon'] ?></strong></td>
                </tr>
                  <tr>
                <td width="20%"></td>
                <td></td>
                </tr>
                </table> <!-- end row --><br /><br />

                
                 <!-- end row --><!-- Page Content Ends -->
            <!-- ================== -->
</div>