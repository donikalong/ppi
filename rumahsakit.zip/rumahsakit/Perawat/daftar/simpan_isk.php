<?php 
  
  include "../../inc/config.php";

  
  

  $iddaftar       = $_POST['id_daftar'];
  $dokter         = $_POST['dokter'];
  $ruangan        = $_POST['ruangan'];
  $jp             = $_POST['jp'];
  $p              = $_POST['p'];
  $keterangan     = $_POST['keterangan'];
  $dc             = $_POST['dc'];
  $tgl_pasang     = $_POST['tgl_pasang'];
  $as             = $_POST['as'];
  $hh             = $_POST['hh'];
  $ti             = $_POST['ti'];
  $fk             = $_POST['fk'];
  $pb             = $_POST['pb'];
  $tgl_periksa    = $_POST['tgl_periksa'];
  $tgl            = date('Y-m-d');
  $adp            = $_POST['adp'];
  $ub             = $_POST['ub'];

      $sql   = "INSERT INTO rawat  VALUES ('$iddaftar','$tgl','$iddaftar','$dokter','$ruangan','Rawat','ISK')";
      $query = mysql_query($sql);
      $sql2   = "INSERT INTO isk  VALUES ('$iddaftar','$jp','$p','$tgl_periksa','$keterangan','$tgl_pasang','$dc','$hh','$fk','$adp','$as','$ti','$pb','$ub','$iddaftar')";
      $query2 = mysql_query($sql2);
   
      if ($query || $query2) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_isk&id_pendaftaran=<?php echo $iddaftar ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>