
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir Phlebitis</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <br>
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="daftar/simpan_phlebitis.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                           <select name="dokter" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql = mysql_query ("SELECT * FROM dokter ORDER BY namadokter ASC");
                                            while ($dt = mysql_fetch_array($mysql)){
                                                ?>
                                                <option value="<?php echo $dt['iddokter'] ?>"><?php echo $dt['namadokter'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <select name="ruangan" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql1 = mysql_query ("SELECT * FROM ruangan ORDER BY kelas ASC");
                                            while ($dt1 = mysql_fetch_array($mysql1)){
                                                ?>
                                                <option value="<?php echo $dt1['idruangan'] ?>"><?php echo $dt1['namaruangan'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Jenis Pemasangan</label>
                                        <div class="col-sm-10">
                                           <input type="radio" value="Kateter V Perifer" name="jp">&nbsp;Kateter V Perifer &nbsp;&nbsp;
                                           <input type="radio" value="Umbilikal" name="jp">&nbsp;Umbilikal &nbsp;&nbsp;
                                           <input type="radio" value="Double Lumen" name="jp">&nbsp;Double Lumen &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tujuan Pemasangan</label>
                                        <div class="col-sm-10">
                                           <input name="tp" type="radio" value="Pemberian Obat">&nbsp;Pemberian Obat &nbsp;&nbsp;
                                           <input name="tp" type="radio" value="Transfusi">&nbsp;Transfusi &nbsp;&nbsp;
                                           <input name="tp" type="radio" value="Nutrisi Parenteral">&nbsp;Nutrisi Parenteral &nbsp;&nbsp;
                                           <input name="tp" type="radio" value="Terapi Cairan">&nbsp;Terapi Cairan &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Keterangan</label>
                                        <div class="col-sm-10">
                                        <textarea style="width: 100%; height: 50px;" name="keterangan" ></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Lokasi</label>
                                        <div class="col-sm-10">
                                           <input name="lokasi" type="radio" value="Tangan Kanan">&nbsp;Tangan Kanan &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Tangan Kiri">&nbsp;Tangan Kiri &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Kaki Kanan">&nbsp;Kaki Kanan &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Kaki Kiri">&nbsp;Kaki Kiri &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Pasang</label>
                                        <div class="col-sm-10">
                                          <input name="tgl_pasang"  type="date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    <table border="0" width="100%">
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputEmail3" class="col-sm-12 control-label">Lakukan Kebersihan Tangan Sebelum dan Sesudah Pemasangan</label>
                                        </td>
                                        <td width="40%"> 
                                            <input name="kt" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="kt" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Melepas Pemasangan Apabila Ada Keluhan/Peradangan</label>
                                        </td>
                                        <td width="30%">
                                            <input name="mp" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="mp" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Lakukan Pengecekan Balutan Pemasangan (Drayssing)</label>
                                        </td>
                                        <td width="40%">
                                            <input name="pb" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="pb" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Melepas Pemasangan Apabila Lebih dari 72 Jam</label>
                                        </td>
                                        <td width="30%">
                                            <input name="mjam" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="mjam" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                     </tr>
                                     <tr>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Lakukan Pengecekan Tempat Pemasangan</label>
                                        </td>
                                        <td width="30%">
                                            <input name="pt" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="pt" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                 
                                        </td>
                                        <td width="30%">
                                            </td>
                                     </tr>
                                    </table>
                                    <br>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Lepas</label>
                                        <div class="col-sm-10">
                                          <input name="tgl_lepas" class="form-control" type="date">
                                        </div>
                                    </div>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     