
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir ISK</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <br>
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="daftar/simpan_isk.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                           <select name="dokter" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql = mysql_query ("SELECT * FROM dokter ORDER BY namadokter ASC");
                                            while ($dt = mysql_fetch_array($mysql)){
                                                ?>
                                                <option value="<?php echo $dt['iddokter'] ?>"><?php echo $dt['namadokter'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <select name="ruangan" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql1 = mysql_query ("SELECT * FROM ruangan ORDER BY kelas ASC");
                                            while ($dt1 = mysql_fetch_array($mysql1)){
                                                ?>
                                                <option value="<?php echo $dt1['idruangan'] ?>"><?php echo $dt1['namaruangan'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Jenis Pemasangan</label>
                                        <div class="col-sm-10">
                                           <input type="radio" value="SPP" name="jp">&nbsp;Kateter V SPP &nbsp;&nbsp;
                                           <input type="radio" value="Dauer" name="jp">&nbsp;Dauer &nbsp;&nbsp;
                                           <input type="radio" value="Intermiten" name="jp">&nbsp;Intermiten &nbsp;&nbsp;
                                           <input type="radio" value="Kondom" name="jp">&nbsp;Kondom &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Pemeriksaan</label>
                                        <div class="col-sm-10">
                                           <input name="p" type="radio" value="Urine">&nbsp;Urine &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                           <input name="p" type="radio" value="Biakan Urine">&nbsp;Biakan Urine &nbsp;&nbsp;
                                        
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Pemeriksaan</label>
                                        <div class="col-sm-10">
                                          <input name="tgl_periksa"  type="date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Keterangan</label>
                                        <div class="col-sm-10">
                                        <textarea style="width: 100%; height: 50px;" name="keterangan" ></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Pasang</label>
                                        <div class="col-sm-10">
                                          <input name="tgl_pasang"  type="date" class="form-control">
                                        </div>
                                    </div>
                                                        
                                    <div class="form-group">
                                    <table border="0" width="100%">
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputEmail3" class="col-sm-12 control-label">Pemasangan DC Sesuai Indikasi</label>
                                        </td>
                                        <td width="40%"> 
                                            <input name="dc" type="radio" value="Ya" >&nbsp;Ya &nbsp;&nbsp;
                                            <input name="dc" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Pemasangan Menggunakan Alat Steril</label>
                                        </td>
                                        <td width="30%">
                                            <input name="as" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="as" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="10%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Melakukan Hand Hyglene</label>
                                        </td>
                                        <td width="40%">
                                            <input name="hh" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="hh" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Segera Dilepas Jika Tidak Indikasi</label>
                                        </td>
                                        <td width="30%">
                                            <input name="ti" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="ti" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                     </tr>
                                     <tr>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">Fiksasi Kateter dengan Plester</label>
                                        </td>
                                        <td width="30%">
                                            <input name="fk" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="fk" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                        <label for="inputPassword3" class="col-sm-12 control-label">Pengisian Balon sesuai indikasi (30ml)</label>
                                        </td>
                                        <td width="30%">
                                            <input name="pb" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="pb" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                     </tr>
                                     <tr>
                                        <td width="20%"> 
                                            <label for="inputPassword3" class="col-sm-12 control-label">ADP Tepat</label>
                                        </td>
                                        <td width="30%">
                                            <input name="adp" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="adp" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                        <td width="20%"> 
                                        <label for="inputPassword3" class="col-sm-12 control-label">Urine Bag Menggantung</label>
                                        </td>
                                        <td width="30%">
                                            <input name="ub" type="radio" value="Ya">&nbsp;Ya &nbsp;&nbsp;
                                            <input name="ub" type="radio" value="Tidak">&nbsp;Tidak
                                        </td>
                                     </tr>
                                    </table>
                                    <br>
                                    </div>
                                    
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     