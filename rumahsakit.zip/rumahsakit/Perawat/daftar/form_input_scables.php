
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir Scables</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <br>
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="daftar/simpan_scables.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                           <select name="dokter" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql = mysql_query ("SELECT * FROM dokter ORDER BY namadokter ASC");
                                            while ($dt = mysql_fetch_array($mysql)){
                                                ?>
                                                <option value="<?php echo $dt['iddokter'] ?>"><?php echo $dt['namadokter'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <select name="ruangan" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql1 = mysql_query ("SELECT * FROM ruangan ORDER BY kelas ASC");
                                            while ($dt1 = mysql_fetch_array($mysql1)){
                                                ?>
                                                <option value="<?php echo $dt1['idruangan'] ?>"><?php echo $dt1['namaruangan'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Kebersihan</label>
                                        <div class="col-sm-10">
                                           <input type="radio" value="Sangat Bersih" name="kebersihan">Sangat Bersih &nbsp;&nbsp;
                                           <input type="radio" value="Cukup Bersih" name="kebersihan">Cukup Bersih &nbsp;&nbsp;
                                           <input type="radio" value="Kurang Bersih" name="kebersihan">Kurang Bersih &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Pemakaian Peralatan</label>
                                        <div class="col-sm-10">
                                           <input name="alat" type="radio" value="Pribadi">Pribadi &nbsp;&nbsp;
                                           <input name="alat" type="radio" value="Bersama">Bersama &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Lingkungan</label>
                                        <div class="col-sm-10">
                                            <input type="radio" value="Bersih" name="lingkungan">Bersih &nbsp;&nbsp;
                                           <input type="radio" value="Kumuh" name="lingkungan">Kumuh &nbsp;&nbsp;
                                           <input type="radio" value="Padat" name="lingkungan">Padat &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Lokasi</label>
                                        <div class="col-sm-10">
                                           <input name="lokasi" type="radio" value="Badan">Badan &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Tangan">Tangan &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Kaki">Kaki &nbsp;&nbsp;
                                           <input name="lokasi" type="radio" value="Kepala">Kepala &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Presentase</label>
                                        <div class="col-sm-10">
                                          <input name="presen" maxlength="3" size="5">%
                                        </div>
                                    </div>
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     