<?php 
  
  include "../../inc/config.php";

  
  

  $iddaftar       = $_POST['id_daftar'];
  $dokter         = $_POST['dokter'];
  $ruangan        = $_POST['ruangan'];
  $jp             = $_POST['jp'];
  $tp             = $_POST['tp'];
  $keterangan     = $_POST['keterangan'];
  $lokasi         = $_POST['lokasi'];
  $tgl_pasang     = $_POST['tgl_pasang'];
  $kt             = $_POST['kt'];
  $mp             = $_POST['mp'];
  $pb             = $_POST['pb'];
  $mjam           = $_POST['mjam'];
  $pt             = $_POST['pt'];
  $tgl_lepas      = $_POST['tgl_lepas'];
  $tgl            = date('Y-m-d');

      $sql   = "INSERT INTO rawat  VALUES ('$iddaftar','$tgl','$iddaftar','$dokter','$ruangan','Rawat','Phlebitis')";
      $query = mysql_query($sql);
      $sql2   = "INSERT INTO phlebitis  VALUES ('$iddaftar','$jp','$tp','$keterangan','$lokasi','$tgl_pasang','$kt','$pb','$pt','$tgl_lepas','$mp','$mjam','$iddaftar')";
      $query2 = mysql_query($sql2);
   
      if ($query || $query2) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_phlebitis&id_pendaftaran=<?php echo $iddaftar ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>