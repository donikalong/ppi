<?php 
  
  include "../../inc/config.php";

  
  

  $iddaftar       = $_POST['id_daftar'];
  $dokter         = $_POST['dokter'];
  $ruangan        = $_POST['ruangan'];
  $kebersihan     = $_POST['kebersihan'];
  $alat           = $_POST['alat'];
  $lingkungan     = $_POST['lingkungan'];
  $lokasi         = $_POST['lokasi'];
  $p              = $_POST['presen'];
  $tgl            = date('Y-m-d');

      $sql   = "INSERT INTO rawat  VALUES ('$iddaftar','$tgl','$iddaftar','$dokter','$ruangan','Rawat','Scables')";
      $query = mysql_query($sql);
      $sql2   = "INSERT INTO scables  VALUES ('$iddaftar','$kebersihan','$alat','$lingkungan','$tgl','$lokasi','$p','$iddaftar')";
      $query2 = mysql_query($sql2);
   
      if ($query || $query2) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_scables&id_pendaftaran=<?php echo $iddaftar ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>