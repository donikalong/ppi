
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Pendaftaran Pasien</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title" style="text-align:right">
                                 </h3>

                            </div>
                            <div class="panel-body">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Tanggal</th>
                                                    <th>No Rekam Medis</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Keluhan</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm order by pendaftaran.tanggal desc");
                                                    $no  = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++; ?></td>
                                                    <td><?php echo $data['tanggal']; ?></td>
                                                    <td><?php echo $data['norm']; ?></td>
                                                    <td><?php echo $data['namapasien']; ?></td>
                                                    <td><?php echo $data['alamat']; ?></td>
                                                    <td><?php echo $data['telpon']; ?></td>
                                                    <td><?php echo $data['keluhan']; ?></td>
                                                    <td>
                                                    
                                                      <?php
													  $no = $data['idpendaftaran'];
													  $fr = mysql_query("select * from rawat where idpendaftaran='$no'");
													  $kk = mysql_num_rows($fr);
													  if ($kk > 0){
													  ?>
                                                      Sudah Diperiksa
                                                      <?php } else {
														  ?>     
                                                      <a href="index.php?mod=daftar&pg=form_input_dekubitus&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-danger m-b-5"> Dekubitus </button></a><br>
                                                      <a href="index.php?mod=daftar&pg=form_input_phlebitis&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-info m-b-5"> Phlebitis </button></a><br>
                                                      <a href="index.php?mod=daftar&pg=form_input_scables&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-primary m-b-5"> Scables </button></a><br>
                                                      <a href="index.php?mod=daftar&pg=form_input_isk&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-danger m-b-5"> ISK </button></a><br>
                                                      
                                                       <?php } ?>

                                                     
                                                                                                 
                                                    </td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           