
<?php 
    $id_daftar = $_GET['id_pendaftaran'];
    $sql   = "SELECT * FROM pendaftaran inner join pasien on pendaftaran.norm = pasien.norm WHERE pendaftaran.idpendaftaran ='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Formulir Dekubitus</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                             <div class="panel-body">
                            <table border="0" width="100%">
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">No Rekam</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['norm'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Asuransi</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['asuransi'];?>" readonly=""></td>
                                </tr>
                                <tr>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Nama</label></td>
                                    <td><input type="text" class="form-control" name="norekam" value="<?php echo $data['namapasien'];?>" readonly=""></td>
                                    <td> <label for="inputPassword3" class="col-sm-2 control-label">Keluhan</label></td>
                                    <td><textarea style="width: 100%; height: 50px;" readonly><?php echo $data['keluhan'];?></textarea></td>
                                </tr>
                            </table>
                            <br>
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="daftar/simpan_dekubitus.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $id_daftar;?>" readonly="">
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">DPJP</label>
                                        <div class="col-sm-10">
                                           <select name="dokter" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql = mysql_query ("SELECT * FROM dokter ORDER BY namadokter ASC");
                                            while ($dt = mysql_fetch_array($mysql)){
                                                ?>
                                                <option value="<?php echo $dt['iddokter'] ?>"><?php echo $dt['namadokter'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ruang Rawat Inap</label>
                                        <div class="col-sm-10">
                                        <select name="ruangan" class="form-control">
                                            <option >Pilih</option>
                                            <?php
                                            $mysql1 = mysql_query ("SELECT * FROM ruangan ORDER BY kelas ASC");
                                            while ($dt1 = mysql_fetch_array($mysql1)){
                                                ?>
                                                <option value="<?php echo $dt1['idruangan'] ?>"><?php echo $dt1['namaruangan'] ?></option>
                                                <?php
                                            }
                                            ?>
                                           </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Kondisi</label>
                                        <div class="col-sm-10">
                                           <input type="radio" value="Baik" name="kondisi">&nbsp;Baik &nbsp;&nbsp;
                                           <input type="radio" value="Sedang" name="kondisi">&nbsp;Sedang &nbsp;&nbsp;
                                           <input type="radio" value="Buruk" name="kondisi">&nbsp;Buruk &nbsp;&nbsp;
                                           <input type="radio" value="Sangat Buruk" name="kondisi">&nbsp;Sangat Buruk &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Status Mental</label>
                                        <div class="col-sm-10">
                                           <input name="mental" type="radio" value="Sadar">&nbsp;Sadar &nbsp;&nbsp;
                                           <input name="mental" type="radio" value="Apatis">&nbsp;Apatis &nbsp;&nbsp;
                                           <input name="mental" type="radio" value="Bingung">&nbsp;Bingung &nbsp;&nbsp;
                                           <input name="mental" type="radio" value="Stupor">&nbsp;Stupor &nbsp;&nbsp;
                                        </div>
                                    </div>
                       
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Aktifitas</label>
                                        <div class="col-sm-10">
                                           <input name="aktifitas" type="radio" value="Jalan Sendiri">&nbsp;Jalan Sendiri &nbsp;&nbsp;
                                           <input name="aktifitas" type="radio" value="Jalan Dengan Bantuan">&nbsp;Jalan Dengan Bantuan &nbsp;&nbsp;
                                           <input name="aktifitas" type="radio" value="Kursi Roda">&nbsp;Kursi Roda &nbsp;&nbsp;
                                           <input name="aktifitas" type="radio" value="Di Tempat Tidur">&nbsp;Di Tempat Tidur &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Mobilitas</label>
                                        <div class="col-sm-10">
                                           <input name="mobilitas" type="radio" value="Bebas Bergerak">&nbsp;Bebas Bergerak &nbsp;&nbsp;
                                           <input name="mobilitas" type="radio" value="Agak Terbatas">&nbsp;Agak Terbatas &nbsp;&nbsp;
                                           <input name="mobilitas" type="radio" value="Sangat Terbatas">&nbsp;Sangat Terbatas &nbsp;&nbsp;
                                           <input name="mobilitas" type="radio" value="Tidak Mampu Bergerak">&nbsp;Tidak Mampu Bergerak &nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Ikontinensia</label>
                                        <div class="col-sm-10">
                                           <input name="inkontinensia" type="radio" value="Kontinen">&nbsp;Kontinen &nbsp;&nbsp;
                                           <input name="inkontinensia" type="radio" value="Kadang Kadang Inkontinensia Urine">&nbsp;Kadang Kadang Inkontinensia Urine &nbsp;&nbsp;
                                           <input name="inkontinensia" type="radio" value="Selalu Inkontinensia Urine">&nbsp;Selalu Inkontinensia Urine &nbsp;&nbsp;
                                           <input name="inkontinensia" type="radio" value="Inkontinensia Urine & Alvi">&nbsp;Inkontinensia Urine & Alvi &nbsp;&nbsp;
                                        </div>
                                    </div>
                            
                                    
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       




    




     