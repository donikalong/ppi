<?php 
  
  include "../../inc/config.php";

  
  

  $iddaftar       = $_POST['id_daftar'];
  $dokter         = $_POST['dokter'];
  $ruangan        = $_POST['ruangan'];
  $kondisi     = $_POST['kondisi'];
  $mental           = $_POST['mental'];
  $mobilitas     = $_POST['mobilitas'];
  $inkontinensia         = $_POST['inkontinensia'];
  $aktifitas      = $_POST['aktifitas'];

  $tgl            = date('Y-m-d');

      $sql   = "INSERT INTO rawat  VALUES ('$iddaftar','$tgl','$iddaftar','$dokter','$ruangan','Rawat','Dekubitus')";
      $query = mysql_query($sql);
      $sql2   = "INSERT INTO dekubitus  VALUES ('$iddaftar','$kondisi','$mental','$aktifitas','$mobilitas','$inkontinensia','$iddaftar')";
      $query2 = mysql_query($sql2);
   
      if ($query || $query2) {
       ?>
        <script type="text/javascript">
        alert("Data sudah disimpan");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_dekubitus&id_pendaftaran=<?php echo $iddaftar ?>";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>