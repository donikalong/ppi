
            <!-- Page Content Start -->
            <!-- ================== -->
      
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Daftar Pasien</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               <!-- <h3 class="panel-title">Data Siswa</h3> -->
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Email</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>No BPJS</th>
                                                    <th>Pekerjaan</th>
                                                    <th>Foto BPJS / KTP</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                            		$sql = mysql_query("SELECT * FROM pasien ORDER BY namapasien ASC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['idpasien'] ?></td>
													<td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                    <td><?php echo $data['nobpjs'] ?></td>
                                                    <td><?php echo $data['pekerjaan'] ?></td>
                                                    <td><a href="../photo/bpjs/<?php echo $data['foto']?>" target="_blank"><img src="../photo/bpjs/<?php echo $data['foto']?>" width="100px" height="100px"></a></td>
                                                    <td>
                                                           
                                                       <a href="index.php?mod=pasien&pg=detail_pasien&idpasien=<?php echo $data['idpasien'];?>"><button class="btn btn-icon btn-info m-b-5"> <i class="fa fa-eye"></i> </button></a>

                                                     
                                                        <a href="pasien/hapus_pasien.php?idpasien=<?php echo $data['idpasien'];?>&foto=<?php echo $data['foto'];?>" onclick="return confirm('Apakah anda yakin ingin menghapus data?') ";><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           