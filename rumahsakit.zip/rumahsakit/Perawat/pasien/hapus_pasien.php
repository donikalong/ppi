<?php 

    include "../../inc/config.php";

    $idpasien = $_GET['idpasien'];
    $foto = $_GET['foto'];

    unlink('../../photo/bpjs/'.$foto);
    $sql   = "DELETE FROM pasien WHERE idpasien='$idpasien'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=pasien&pg=data_pasien'</script>";
 ?>