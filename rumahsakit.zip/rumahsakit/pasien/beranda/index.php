<?php
	$username = $_SESSION['username']; 
	$sql_sdm       = mysql_query("SELECT * FROM pasien where username='$username'");
	$sql_jadwal    = mysql_query("SELECT count(id_jadwal) AS jumlah_jadwal FROM tbl_jadwal");
	$data_sdm      = mysql_fetch_assoc($sql_sdm);
	$data_jadwal   = mysql_fetch_assoc($sql_jadwal);

 ?>

			 <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Selamat Datang</h3> 
                </div>

                <?php
				$user = $_SESSION['username'];
				$ml = mysql_query("select * from pasien where username='$user'");
				$kj = mysql_fetch_array($ml);
				?>
                <table border="0" width="100%">
                
                <tr>
                <td colspan="2"</td>
                </tr>
                <tr>
                <td width="20%">No Rekam Medis</td>
                <td>: <strong><?php echo $kj['norm'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Email</td>
                <td>: <strong><?php echo $kj['email'] ?></strong></td>
                </tr>
                
                <tr>
                <td width="20%">Nama Pasien</td>
                <td>: <strong><?php echo $kj['namapasien'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Alamat</td>
                <td>: <strong><?php echo $kj['alamat'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Telpon</td>
                <td>: <strong> <?php echo $kj['telpon'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Agama</td>
                <td>: <strong><?php echo $kj['agama'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Tempat / Tanggal Lahir</td>
                <td>: <strong><?php echo $kj['tempat'] ?> / <?php echo $kj['tl'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Asuransi</td>
                <td>: <strong><?php echo $kj['asuransi'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%">Jenis Kelamin</td>
                <td>: <strong><?php echo $kj['jk'] ?></strong></td>
                </tr>
                <tr>
                <td width="20%"></td>
                <td></td>
                </tr>
                </table> <!-- end row --><br /><br />
                <!--
             <a href="index.php?mod=pasien&pg=detail_pasien"><button>Ubah Profil</button></a>
            -->
            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->
