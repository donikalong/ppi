
        <div class="container">
            <h2 class="text-center"><i class="fa fa-calendar"></i> Resep Obat</h2> 
            <?php
                                if (!empty($catatan)){
                            ?>
                 <div class="alert alert-warning" id="MessageNotSent">
                CATATAN: <?php echo $catatan ?>
              </div>      
              <?php
                }
              ?>      
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Obat</th>
                                                    <th>Jumlah Obat</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
												$user = $_SESSION['username'];
												$idrekam = $_GET['id_rekam'];
                                            		$sql = mysql_query("SELECT * FROM resep inner join obat on resep.kodeobat = obat.kodeobat where resep.noresep='$idrekam' ");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['namaobat'] ?></td>
                                                    <td><?php echo $data['jumlah'] ?></td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
            </div><!-- /.box-body -->
        </div>  
       
   