
        <div class="container">
            <h2 class="text-center"><i class="fa fa-calendar"></i> Daftar Rekam Medis</h2> 
            <?php
                                if (!empty($catatan)){
                            ?>
                 <div class="alert alert-warning" id="MessageNotSent">
                CATATAN: <?php echo $catatan ?>
              </div>      
              <?php
                }
              ?>      
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Pendaftaran</th>
                                                    <th>Tanggal</th>
                                                    <th>Email</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>Agama</th>
                                                     <th>Infeksi</th>
                                                 
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <?php 
												$user = $_SESSION['username'];
                                            		$sql = mysql_query("SELECT * FROM pasien inner join pendaftaran on pasien.norm = pendaftaran.norm inner join rawat on pendaftaran.idpendaftaran = rawat.idpendaftaran where pasien.username='$user' ORDER BY rawat.tglmasuk DESC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['idpendaftaran'] ?></td>
                                                    <td><?php echo $data['tanggal'] ?></td>
                                                    <td><?php echo $data['email'] ?></td>
                                                    <td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                    <td><?php echo $data['agama'] ?></td>
                                                     <td><?php echo $data['infeksi'] ?></td>
                                                
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
            </div><!-- /.box-body -->
        </div>  
       
   