<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php 
include "../../inc/config.php";
$id       = $_GET['id_daftar']; 
                              
?>
<body onload="window.print() ">
<table width="100%" border="0">

  <tr>
  <td width="10%"><img src="../../images/logo.jpeg" width="100%" /></td>
    <td align="center" colspan="3" bgcolor="#FFFFFF"><h2>Klinik Teluk Sehat Medika<br /></h2>
    <strong>Alamat: J<span class="adr clearfix col-md-12 col-sm-4"><span class="adr-group pull-left"><span class="street-address">l.</span> RE Martadinata, Keteguhan,</span><span class="adr-group pull-left">Teluk Betung Timur<br />
    <span class="country-name">Kota Bandar Lampung</span></span></span></strong></td>
    
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4"> <hr size="3" color="#000000"/> </td>
  </tr>
  <tr>
    <td colspan="4" align="center"><strong>REKAM MEDIS <br /> PASIEN RAWAT JALAN
    <?php
    	$sql = mysql_query("SELECT * FROM pasien inner join pendaftaran on pasien.idpasien = pendaftaran.idpasien inner join rekammedis on pendaftaran.nopendaftaran = rekammedis.nopendaftaran where pendaftaran.nopendaftaran = '$id'");
                                               
                                            	$data = mysql_fetch_array($sql);
	?>
     <br />
      <br />
    </strong></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
    <td></td>
    <td>No Pendaftaran</td>
    <td><?php echo $data ['nopendaftaran'] ?></td>
  </tr>
  <tr>
  <td width="10%">Nama Lengkap</td>
    <td width="40%">:<?php echo $data ['namapasien'] ?></td>
    <td width="10%">Kriteria Pasien</td>
    <td width="40%">&nbsp;</td>
  </tr>
    <tr>
  <td>ID Pasien</td>
    <td>:<?php echo $data ['idpasien'] ?></td>
   
    <td>Agama</td>
   
    <td>:<?php echo $data ['agama'] ?></td>
    
  </tr>
    <tr>
  <td>Tanggal Lahir</td>
    <td>:<?php echo $data ['tl'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>Jenis Kelamin</td>
    <td>:<?php echo $data ['jk'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>Pekerjaan</td>
    <td>:<?php echo $data ['pekerjaan'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>Alamat</td>
    <td>:<?php echo $data ['alamatpasien'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>Telpon</td>
    <td>:<?php echo $data ['telpon'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>Tanggal Berobat</td>
    <td>:<?php echo $data ['tanggal'] ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  <tr>
    <td colspan="4">
    <table width="100%" border="1" cellpadding="0" cellspacing="0">
      <thead>
                                                <tr>
                                                    <th width="25%">Autonamnesis dan Pemeriksaan</th>
                                                    <th width="25%">Rencana Terapi</th>
                                                    <th width="25%">Paraf </th>
                                                 </tr>
                                            </thead>
                                     
                                            <tbody>
                                                <tr>
                                                    <td valign="top">
                                                    Anamesis : <br />
                                                    <?php echo $data ['anamesis'] ?> <br />
                                                    Pemeriksaan :<br />
                                                    <?php echo $data ['pemeriksaan'] ?> <br />
                                                    </td>
                                                    <td valign="top">Rencana Terapi : <br />
                                                    <?php echo $data ['rencanaterapi'] ?> <br />
                                                   </td>
                                                   <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4"><table width="100%" border="0">
      <tr>
        <td width="79%" colspan="3">&nbsp;</td>
        <td width="21%">Bandar Lampung, <?php echo date('Y-m-d');?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3">&nbsp;</td>
        <td><strong>Dr.Christian</strong></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>