
<?php 
    $id_daftar = $_SESSION['username'];
    $sql   = "SELECT * FROM pasien WHERE username='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Profil Pasien</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                            
                                <form name="form" id="form" method="post" enctype="multipart/form-data" action="pasien/edit_pasien.php">
					<table id="example1" class="table table-bordered table-striped">
						<tr>
							<td>Email</td><td>: <input name="email" id="email" class="form-control" type="text" value="<?php echo $data['idpasien'] ?>" size="20"  readonly /> </td>
						</tr>
						<tr>
							<td>Nama</td><td>: <input name="nama" id="nama" class="form-control" onkeypress="return event.charCode < 48 || event.charCode  >57" type="text" size="25" value="<?php echo $data['namapasien'] ?>"  /> </td>
						</tr>
						<tr>
							<td>Alamat</td><td>: <textarea name="alamat" id="alamat" style="width: 50%; height: 100px;" id="alamat" ><?php echo $data['alamatpasien'] ?></textarea> </td>
						</tr>
						<tr>
							<td>Jenis Kelamin</td><td>: 
							                  <input name='jk' type='radio'   id='jk' value='Laki - Laki' size='6' maxlength='10' readonly='readonly' checked='checked' />
        Laki - Laki
        <input name='jk' type='radio' id='jk' value='Perempuan' size='15' maxlength='15' readonly='readonly' />
        Perempuan
						</td>
						</tr>
						<tr>
							<td>No BPJS</td><td>: <input name="nobpjs" id="nobpjs" class="form-control" value="<?php echo $data['nobpjs'] ?>" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Pekerjaan</td><td>: <input name="pekerjaan" value="<?php echo $data['pekerjaan'] ?>" id="pekerjaan" class="form-control" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Telpon</td><td>: <input name="telpon" id="telpon" class="form-control" value="<?php echo $data['telpon'] ?>" type="text" size="15" /> </td>
						</tr>
                        <tr>
							<td>Tempat / Tanggal Lahir</td><td>: <input name="ttl" value="<?php echo $data['ttl'] ?>" id="ttl" type="text" size="15" />&nbsp;/&nbsp;<input name="tl" id="tl" value="<?php echo $data['tl'] ?>"  type="date" /> </td>
						</tr>
                        
                        <tr>
							<td>Upload BPJS</td><td>: <input name="photo1" type="file" size="20" /> </td>
						</tr>
                        <tr>
     						<td></td><td><input type="submit" name="Simpan" value="Simpan" /></td>
    					</tr>
					</table>
				</form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       
</head>
<body>

                

            </div>

            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2016 © Maria Francisca Adriyanto.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        



    




        <!-- js placed at the end of the document so the pages load faster -->
        <script src="../assets/back-end/js/jquery.js"></script>
        <script src="../assets/back-end/js/bootstrap.min.js"></script>
        <script src="../assets/back-end/js/modernizr.min.js"></script>
        <script src="../assets/back-end/js/pace.min.js"></script>
        <script src="../assets/back-end/js/wow.min.js"></script>
        <script src="../assets/back-end/js/jquery.scrollTo.min.js"></script>
        <script src="../assets/back-end/js/jquery.nicescroll.js" type="text/javascript"></script>
        
        <script src="../assets/back-end/assets/chat/moment-2.2.1.js"></script>

        <script src="../assets/back-end/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/timepicker/bootstrap-datepicker.js"></script>
        <script src="../assets/back-end/assets/summernote/summernote.min.js"></script>

        <!-- Counter-up -->
        <script src="../assets/back-end/js/waypoints.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/js/jquery.counterup.min.js" type="text/javascript"></script>

        <!-- EASY PIE CHART JS -->
        <script src="../assets/back-end/assets/easypie-chart/easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/jquery.easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/example.js"></script>


        <!--C3 Chart-->
        <script src="../assets/back-end/assets/c3-chart/d3.v3.min.js"></script>
        <script src="../assets/back-end/assets/c3-chart/c3.js"></script>

        <!--Morris Chart-->
        <script src="../assets/back-end/assets/morris/morris.min.js"></script>
        <script src="../assets/back-end/assets/morris/raphael.min.js"></script>

        <!-- sparkline --> 
        <script src="../assets/back-end/assets/sparkline-chart/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/sparkline-chart/chart-sparkline.js" type="text/javascript"></script> 

        <!-- sweet alerts -->
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.min.js"></script>
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.init.js"></script>

        <script src="../assets/back-end/js/jquery.app.js"></script>




    </body>

<!-- Mirrored from coderthemes.com/velonic/admin/form-advanced.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Oct 2015 06:32:48 GMT -->
</html>
         <script>
$(function(){
                        $("#datepicker").datepicker({
                        format:'yyyy-mm-dd'
                        });
                        $("#datepicker2").datepicker({
                        format:'yyyy-mm-dd'
                        });
                      });
</script>