<?php 
  
  include "../../inc/config.php";

  
  

  $iduser         = $_POST['iduser'];
  $keluhan        = $_POST['keluhan'];
  $tanggal       = date('Y=m-d');

      $sql   = "INSERT INTO pendaftaran VALUES(null,'$tanggal','$iduser','$keluhan')";

      $query = mysql_query($sql);

      if ($query) {
       ?>
        <script type="text/javascript">
        alert("Selamat Anda sudah berhasil mendaftar");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_mendaftar";
        </script>
        <?php 
      } 

 
  mysql_close();
 ?>