<?php
include("../inc/config.php");
$iduser = $_GET['id_daftar'];
$sql = mysql_query("select * from pendaftaran inner join pasien on pendaftaran.nokk = pasien.nokk where nopendaftaran= '$iduser' ");
$dt = mysql_fetch_array($sql);
$idpemesanan = $dt['nopendaftaran'];
$harga = $dt['subtotal'];

?>
     <script src="../css/jquery-1.10.2.min.js" type="text/javascript"></script>

      <!-- Script Timer -->
		 <script type="text/javascript">
			$(document).ready(function() {
				  /** Membuat Waktu Mulai Hitung Mundur Dengan 
					* var detik = 0,
					* var menit = 1,
					* var jam = 1
				  */
				  var detik = 00;
				  var menit = 00;
				  var jam 	= 24;
				 
				 /**
				   * Membuat function hitung() sebagai Penghitungan Waktu
				 */
				function hitung() {
					/** setTimout(hitung, 1000) digunakan untuk 
						* mengulang atau merefresh halaman selama 1000 (1 detik) 
					*/
					setTimeout(hitung,1000);
	 
				   /** Jika waktu kurang dari 10 menit maka Timer akan berubah menjadi warna merah */
				   if(menit < 10 && jam == 0){
						 var peringatan = 'style="color:red"';
				   };
 
				   /** Menampilkan Waktu Timer pada Tag #Timer di HTML yang tersedia */
				   $('#timer').html(
						  '<h1 align="center"'+peringatan+'>Sisa waktu pembayaran anda <br />' + jam + ' jam : ' + menit + ' menit : ' + detik + ' detik</h1>'
					);
	 
					/** Melakukan Hitung Mundur dengan Mengurangi variabel detik - 1 */
					detik --;
 
					/** Jika var detik < 0
						* var detik akan dikembalikan ke 59
						* Menit akan Berkurang 1
					*/
					if(detik < 0) {
						detik = 59;
						menit --;
 
						/** Jika menit < 0
							* Maka menit akan dikembali ke 59
							* Jam akan Berkurang 1
						*/
						if(menit < 0) {
							menit = 59;
							jam --;

							/** Jika var jam < 0
								* clearInterval() Memberhentikan Interval dan submit secara otomatis
							*/
							if(jam < 0) {                                                                 
								clearInterval();
								
							} 
						} 
					} 
				}           
				/** Menjalankan Function Hitung Waktu Mundur */ 
				hitung();
		  }); 
		  // ]]>
		</script>
   
			
		
		?>
       <div align="center"><h1>Klinik Teluk Sehat Medika</h1><hr /></div>
<div align="center" id='timer'></div>
<div align="center">
	<h4>No Pendaftaran <br />
    <?php echo $dt['nopendaftaran'] ?></h4>
    <h4>Tanggal Pendaftaran <br />
    <?php echo $dt['tanggal'] ?></h4>
        <br /><br />
    <h4>Silahkan Tunjukan No Antrian ke Petugas </h4><br />
   <div>
    <a href="../index.php?module=pembayaran" ><button>Kembali !!</button></a>
</div>

<!-- start banner Area -->
			<!-- End banner Area -->
			

          
           