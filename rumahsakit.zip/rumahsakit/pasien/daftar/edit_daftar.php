<?php 
  error_reporting(0);
  include "../../inc/config.php";

  $id_daftar    = $_POST['id_daftar'];
  $idpasien      = $_POST['idpasien'];
  $diagnosa         = $_POST['diagnosa'];
  $tanggal = date('Y-m-d');


          $sql1   = "insert into rekammedis values ('null','$tanggal','$id_daftar','$diagnosa')";

        $query1 = mysql_query($sql1);
    
 
  if ($query1){
    ?>
        <script type="text/javascript">
        alert("Data berhasil disimpan");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
    <?php
  }
  else{
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=detail_pendaftaran&id_daftar=<?php echo $id_daftar ?>" ;
        </script>
    <?php 
  }  
  mysql_close();


 ?>