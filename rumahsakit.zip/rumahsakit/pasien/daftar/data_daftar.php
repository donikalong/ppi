
            <!-- Page Content Start -->
            <!-- ================== -->
      
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Pendaftaran</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                   <h3 class="panel-title" style="text-align:right"><a href="index.php?mod=daftar&pg=form_input_daftar"><button class="btn btn-success m-b-5"> <i class="fa fa-plus"></i> <span>Pendaftaran</span> </button>
                                </a>
                        
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Pendaftaran</th>
                                                    <th>Tanggal</th>
                                                    <th>Email</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>Asuransi</th>
                                                   
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
												$user = $_SESSION['username'];
												$tanggal = date('Y-m-d');
                                            		$sql = mysql_query("SELECT * FROM pasien inner join pendaftaran on pasien.norm = pendaftaran.norm where pasien.username='$user' ORDER BY pendaftaran.idpendaftaran ASC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;  ?></td>
                                                    <td><?php echo $data['idpendaftaran'] ?></td>
                                                    <td><?php echo $data['tanggal'] ?></td>
                                                    <td><?php echo $data['email'] ?></td>
                                                    <td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                    <td><?php echo $data['asuransi'] ?></td>
                                        
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           