<?php 

    include "../../inc/config.php";

    $id_daftar = $_GET['id_daftar'];
    $foto = $_GET['foto'];

    unlink('../../photo/siswa/'.$foto);
    $sql   = "DELETE FROM siswa inner join pendaftaran on siswa.idsiswa = pendaftaran.idsiswa WHERE idpendaftaran='$id_daftar'";
    $query = mysql_query($sql);

    echo "<script>document.location.href='../index.php?mod=siswa&pg=data_siswa'</script>";
 ?>