<?php 
  
  include "../../inc/config.php";

  
  

  $iduser         = $_POST['iduser'];
  $keluhan        = $_POST['keluhan'];
  $tanggal       = date('Y=m-d');
  $jam = $_POST['jam'];

      $sql   = "INSERT INTO pendaftaran VALUES('','$tanggal','$iduser','$keluhan','$jam')";

      $query = mysql_query($sql);

      if ($query) {
		   // tampung data kiriman
				$nomor = $id;
			
			// include file qrlib.php
			 include "../../phpqrcode/qrlib.php";
			
			//Nama Folder file QR Code kita nantinya akan disimpan
				$tempdir = "../../temp/";
			
				//jika folder belum ada, buat folder 
			if (!file_exists($tempdir)){
				mkdir($tempdir);
			}
			
				#parameter inputan
			$isi_teks = "No Pendaftaran : ".$nomor;
			$namafile = $id.".png";
			$quality = 'H'; //ada 4 pilihan, L (Low), M(Medium), Q(Good), H(High)
			$ukuran = 5; //batasan 1 paling kecil, 10 paling besar
			$padding = 2;
			
			QRCode::png($isi_teks,$tempdir.$namafile,$quality,$ukuran,$padding);
       ?>
        <script type="text/javascript">
        alert("Selamat Anda sudah berhasil mendaftar");
        document.location="../index.php?mod=daftar&pg=data_daftar";
        </script>
      <?php
      }
      else {
        ?>
        <script type="text/javascript">
        alert("Data gagal disimpan");
        document.location="../index.php?mod=daftar&pg=form_input_mendaftar";
        </script>
        <?php 
      } 

 
  mysql_close();
	 
 ?>