
<?php 
    $id_daftar = $_GET['id_daftar'];
    $sql   = "SELECT * FROM pasien inner join pendaftaran on pasien.idpasien = pendaftaran.idpasien WHERE nopendaftaran='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Pemeriksaan Pasien</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                            
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="daftar/edit_daftar.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">No Pendaftaran</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="id_daftar" value="<?php echo $data['nopendaftaran'];?>" readonly="">
                                          <input type="hidden" class="form-control" name="idpasien" value="<?php echo $data['idpasien'];?>" readonly="">
                                          
                                        </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Nama Pasien</label>
                                        <div class="col-sm-10">
                                           <input type="text" class="form-control" name="nama" value="<?php echo $data['namapasien'];?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Telpon</label>
                                        <div class="col-sm-10">
                                           <input type="text" class="form-control" name="telpon" value="<?php echo $data['telpon'];?>" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Nomor BPJS </label>
                                        <div class="col-sm-10">
                                           <input type="text" class="form-control" name="telp" value="<?php echo $data['nobpjs'];?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Keluhan</label>
                                        <div class="col-sm-10">
                                       	<textarea name="keluhan" class="form-control"><?php echo $data['keluhan'];?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Hasil Diagnosa</label>
                                        <div class="col-sm-10">
                                           <textarea name="diagnosa" class="form-control"></textarea>
                                        </div>
                                    </div>
                                     
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           

       
</head>
<body>

                

            </div>

            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2016 © Maria Francisca Adriyanto.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        



    




        <!-- js placed at the end of the document so the pages load faster -->
        <script src="../assets/back-end/js/jquery.js"></script>
        <script src="../assets/back-end/js/bootstrap.min.js"></script>
        <script src="../assets/back-end/js/modernizr.min.js"></script>
        <script src="../assets/back-end/js/pace.min.js"></script>
        <script src="../assets/back-end/js/wow.min.js"></script>
        <script src="../assets/back-end/js/jquery.scrollTo.min.js"></script>
        <script src="../assets/back-end/js/jquery.nicescroll.js" type="text/javascript"></script>
        
        <script src="../assets/back-end/assets/chat/moment-2.2.1.js"></script>

        <script src="../assets/back-end/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/timepicker/bootstrap-datepicker.js"></script>
        <script src="../assets/back-end/assets/summernote/summernote.min.js"></script>

        <!-- Counter-up -->
        <script src="../assets/back-end/js/waypoints.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/js/jquery.counterup.min.js" type="text/javascript"></script>

        <!-- EASY PIE CHART JS -->
        <script src="../assets/back-end/assets/easypie-chart/easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/jquery.easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/example.js"></script>


        <!--C3 Chart-->
        <script src="../assets/back-end/assets/c3-chart/d3.v3.min.js"></script>
        <script src="../assets/back-end/assets/c3-chart/c3.js"></script>

        <!--Morris Chart-->
        <script src="../assets/back-end/assets/morris/morris.min.js"></script>
        <script src="../assets/back-end/assets/morris/raphael.min.js"></script>

        <!-- sparkline --> 
        <script src="../assets/back-end/assets/sparkline-chart/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/sparkline-chart/chart-sparkline.js" type="text/javascript"></script> 

        <!-- sweet alerts -->
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.min.js"></script>
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.init.js"></script>

        <script src="../assets/back-end/js/jquery.app.js"></script>




    </body>

<!-- Mirrored from coderthemes.com/velonic/admin/form-advanced.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Oct 2015 06:32:48 GMT -->
</html>
         <script>
$(function(){
                        $("#datepicker").datepicker({
                        format:'yyyy-mm-dd'
                        });
                        $("#datepicker2").datepicker({
                        format:'yyyy-mm-dd'
                        });
                      });
</script>