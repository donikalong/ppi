<?php
include("../inc/config.php");
$iduser = $_GET['id_daftar'];
$sql = mysql_query("select * from pendaftaran inner join pasien on pendaftaran.nokk = pasien.nokk where nopendaftaran= '$iduser' ");
$dt = mysql_fetch_array($sql);
$idpemesanan = $dt['nopendaftaran'];
$harga = $dt['subtotal'];

?>
     
       <div align="center"><h1>Klinik Teluk Sehat Medika</h1><hr /></div>
<div align="center" id='timer'></div>
<div align="center">
	<h4>No Pendaftaran <br />
    <?php echo $dt['nopendaftaran'] ?></h4>
    <h4>Tanggal Pendaftaran <br />
    <?php echo $dt['tanggal'] ?></h4>
        <br /><br />
   <div>
   <form name="form" id="form" method="post" enctype="multipart/form-data" action="daftar/simpan_daftarumum.php">
					<table id="example1" class="table table-bordered table-striped">
						<tr>
						<tr>
							<td>No Kartu Keluarga</td><td>: <input name="nokk" id="nokk" class="form-control" value="<?php echo $dt['nokk'] ?> "  readonly type="text" size="20" /> </td>
						</tr>
						

							<td>NIK</td><td>:<input name="nodaftar" value="<?php echo $dt['nopendaftaran'] ?>" type="hidden"> <input name="email" id="email" class="form-control" type="text" size="20" /> </td>
						</tr>
						<tr>
							<td>Nama</td><td>: <input name="nama" id="nama" class="form-control" onkeypress="return event.charCode < 48 || event.charCode  >57" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Alamat</td><td>: <textarea name="alamat" id="alamat" style="width: 50%; height: 100px;" id="alamat" ></textarea> </td>
						</tr>
						<tr>
							<td>Jenis Kelamin</td><td>: 
							                  <input name='jk' type='radio'   id='jk' value='Laki - Laki' size='6' maxlength='10' readonly='readonly' checked='checked' />
        Laki - Laki
        <input name='jk' type='radio' id='jk' value='Perempuan' size='15' maxlength='15' readonly='readonly' />
        Perempuan
						</td>
						</tr>
						<tr>
							<td>Agama<td>: 
							<select name="agama" class="form-control" >
							<option value="ISLAM">ISLAM</option>
							<option value="Kristen">Kristen</option>
							<option value="Hindu">Hindu</option>
							<option value="Budha">Budha</option>
							<option value="Katolik">Katolik</option>
							</select>
							</td>
						</tr>
						<tr>
							<td>Tempat / Tanggal Lahir</td><td>: <input name="ttl" id="ttl" type="text" size="15" />&nbsp;/&nbsp;<input name="tl" id="tl"  type="date" /> </td>
						</tr>
						<tr>
							<td>Pekerjaan</td><td>: <input name="pekerjaan" id="pekerjaan" class="form-control" type="text" size="25" /> </td>
						</tr>
						<tr>
							<td>Telpon</td><td>: <input name="telpon" id="telpon" class="form-control" type="text" size="15" /> </td>
						</tr>
						<tr>
							<td>Username</td><td>: <input name="username" id="username" class="form-control" type="text" size="15" /> </td>
						</tr>
						<tr>
							<td>Password</td><td>: <input name="password" type="password" class="form-control" size="20" /> </td>
						</tr>
                        <tr>
							<td>Upload KTP</td><td>: <input name="photo1" type="file" size="20" /> </td>
						</tr>
                       
						<tr>
							<td>Keluhan</td><td>: <textarea name="keluhan" class="form-control" ></textarea> </td>
						</tr>
						<tr>
     						<td></td><td><input type="submit" name="Simpan" value="Simpan" /></td>
    					</tr>
					</table>
				</form>

				<table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>NIK</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>Pekerjaan</th>
													<th>Keluhan</th>
                                                  </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
												$user = $_SESSION['username'];
												$tanggal = date('Y-m-d');
                                            		$sql = mysql_query("SELECT * FROM pasien inner join detailpendaftaran on pasien.idpasien = detailpendaftaran.idpasien where detailpendaftaran.nopendaftaran='$iduser' ORDER BY detailpendaftaran.nopendaftaran ASC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;  ?></td>
                                                    <td><?php echo $data['idpasien'] ?></td>
                                                    <td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamatpasien'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                    <td><?php echo $data['pekerjaan'] ?></td>
													<td><?php echo $data['keluhan'] ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
</div>

<!-- start banner Area -->
			<!-- End banner Area -->
			

          
           