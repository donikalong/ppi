

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Input Berita</h3> 
                </div>

                <div class="row">
                    <!-- Horizontal form -->
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title"></h3></div>
                            <div class="panel-body">
                                <form class="form-horizontal" name="form1" method="POST" enctype="multipart/form-data" action="berita/simpan_berita.php" >
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Judul Berita</label>
                                        <div class="col-sm-10">
                                          <input type="text" class="form-control" name="judul" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Berita</label>
                                        <div class="col-sm-10">
                                           <textarea class="wysihtml5 form-control" rows="9" name="berita"></textarea>
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Tanggal</label>
                                        <div class="col-sm-10">
                                           <input type="text" class="form-control" name="tanggal" readonly="" value="<?php echo date('Y-m-d')?>" >
                                        </div>
                                    </div>                                   
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Foto</label>
                                        <div class="col-sm-10">
                                          <input type="file" class="form-control" name="photo1" >
                                        </div>
                                    </div>
                                    
                                    <div class="form-group m-b-0">
                                        <div class="col-sm-offset-3 col-sm-9">
                                          <button type="submit" class="btn btn-info">Simpan</button>
                                          <button type="submit" class="btn btn-info">Bersih</button>
                                        </div>
                                    </div>
                                </form>
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->

                </div>
                
            </div>
           
