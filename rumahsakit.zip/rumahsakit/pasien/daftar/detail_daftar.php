
<?php 
    $id_daftar = $_GET['id_daftar'];
    $sql   = "SELECT * FROM siswa inner join pendaftaran on siswa.idsiswa = pendaftaran.idsiswa WHERE idpendaftaran='$id_daftar'";
    $query = mysql_query($sql);
    $data  = mysql_fetch_array($query); 

?>
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><button class="btn btn-success m-b-5" onclick="self.history.back()"> <i class="fa fa-arrow-left"></i> <span>Kembali</span> </button></h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               <!-- <h3 class="panel-title">Data Siswa</h3> -->
                            <Form method="post" name="form1" action="siswa/simpan_siswa.php" enctype="multipart/form-data">
                                    <table class="table table-boxed">
                                        <thead>
                                            <tr>
                                                <th colspan="3"><h2 style="text-align:center;">Rincian Data Siswa</h2></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">No Pendaftaran</td>
                                                <td width="239"><?php echo $data['idpendaftaran'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">ID Siswa</td>
                                                <td>
                                                     <?php echo $data['idsiswa'];?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama Siswa</td>
                                                <td width="239"> <?php echo $data['namasiswa'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Alamat</td>
                                                <td> <?php echo $data['alamatsiswa'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Telpon</td>
                                                <td> <?php echo $data['telpon'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Nama Orang Tua</td>
                                                <td> <?php echo $data['namaortu'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Jenis Kelamin</td>
                                                <td>
                                                     <?php echo $data['jk'];?>  
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Pekerjaan orang Tua</td>
                                                <td>
                                                    <?php echo $data['pekerjaan'];?> 
                                                </td>
                                            </tr>
                                           
                                            <tr>
                                                <td colspan="2" style="text-align:left;">Foto</td>
                                                <td><a href="../../photo/siswa/<?php echo $data['foto']?>"><img src="../../photo/siswa/<?php echo $data['foto']?>" width="100px" height="100px"></a></td>
                                            </tr>
                                            
                                             
                                        </tbody>
                                    </table>
									</form>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           