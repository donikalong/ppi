
        
            <div id="promo-slider" class="slider flexslider">
                <ul class="slides">
                    
                    <li>
                        <img src="assets/front-end/images/slides/slide-3.jpg"  alt="" />
                       <p class="flex-caption">
                            <span class="main" >KLINIK DOKTER ROSDIANA</span>
                            <br />
                            <span class="secondary clearfix" >Selalu mengedepankan pelayanan masyarakat</span>
                        </p>
                    </li> 
                </ul><!--//slides-->
            </div><!--//flexslider-->