<!-- Footer Start -->
            <br>
            <br>
            <br>
            <footer class="footer">
                <?php
                $tgl = date('Y');
                ?>
                <?php echo $tgl ?> © RS Ernaldi Bahar
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        


        <!-- js placed at the end of the document so the pages load faster -->
        <script src="../assets/back-end/js/jquery.js"></script>
        <script src="../assets/back-end/js/bootstrap.min.js"></script>
        
        <script src="../assets/back-end/js/modernizr.min.js"></script>
        <script src="../assets/back-end/js/pace.min.js"></script>
        <script src="../assets/back-end/js/wow.min.js"></script>
        <script src="../assets/back-end/js/jquery.scrollTo.min.js"></script>
        <script src="../assets/back-end/js/jquery.nicescroll.js" type="text/javascript"></script>
        
        <script src="../assets/back-end/assets/chat/moment-2.2.1.js"></script>

        <script src="../assets/back-end/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>

        <script src="../assets/back-end/assets/timepicker/bootstrap-datepicker.js"></script>
        <script src="../assets/back-end/assets/summernote/summernote.min.js"></script>

        <!-- Counter-up -->
        <script src="../assets/back-end/js/waypoints.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/js/jquery.counterup.min.js" type="text/javascript"></script>

        <!-- EASY PIE CHART JS -->
        <script src="../assets/back-end/assets/easypie-chart/easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/jquery.easypiechart.min.js"></script>
        <script src="../assets/back-end/assets/easypie-chart/example.js"></script>


        <!--C3 Chart-->
        <script src="../assets/back-end/assets/c3-chart/d3.v3.min.js"></script>
        <script src="../assets/back-end/assets/c3-chart/c3.js"></script>

        <!--Morris Chart-->
        <script src="../assets/back-end/assets/morris/morris.min.js"></script>
        <script src="../assets/back-end/assets/morris/raphael.min.js"></script>

        <!-- sparkline --> 
        <script src="../assets/back-end/assets/sparkline-chart/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="../assets/back-end/assets/sparkline-chart/chart-sparkline.js" type="text/javascript"></script> 

        <!-- sweet alerts -->
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.min.js"></script>
        <script src="../assets/back-end/assets/sweet-alert/sweet-alert.init.js"></script>

        <script src="../assets/back-end/js/jquery.app.js"></script>

        <script src="../assets/back-end/assets/datatables/jquery.dataTables.min.js"></script>
        <script src="../assets/back-end/assets/datatables/dataTables.bootstrap.js"></script>
        <!-- Chat -->
        <script src="../assets/back-end/js/jquery.chat.js"></script>
        <!-- Dashboard -->
        <script src="../assets/back-end/js/jquery.dashboard.js"></script>

        <!-- Todo -->
        <script src="../assets/back-end/js/jquery.todo.js"></script>

        <script>
        $(function(){
                                $("#datepicker").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker1").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker2").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker3").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker4").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker5").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker6").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker7").datepicker({
                                format:'yyyy-mm-dd'
                                });
                                $("#datepicker8").datepicker({
                                format:'yyyy-mm-dd'
                                });
                              });
        </script>
        <script type="text/javascript">

             jQuery(document).ready(function(){



                $('.wysihtml5').wysihtml5();

                $('.summernote').summernote({
                    height: 200,                 // set editor height

                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor

                    focus: true                 // set focus to editable area after initializing summernote
                });

            });

            $(document).ready(function() {
                $('#datatable').dataTable();
            } );
        /* ==============================================
             Counter Up
             =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });

            

        </script>
        

    </body>

<!-- Mirrored from coderthemes.com/velonic/admin/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Oct 2015 06:31:53 GMT -->
</html>
