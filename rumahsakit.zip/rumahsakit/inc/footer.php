</div><!--//content-->
    </div><!--//wrapper-->
    
     <!-- ******FOOTER****** --> 
    <footer class="footer">
        <div class="footer-content">
            <div class="container">
                <div class="row">
                <div class="footer-col col-md-3 col-sm-4 about">
                    <div class="footer-col-inner">
                    </div><!--//footer-col-inner-->
                </div><!--//foooter-col-->
                <div class="footer-col col-md-6 col-sm-8 newsletter">
                    <div class="footer-col-inner">
                    <?php
					if (empty($level)){
					?>
                    
                      
                        <form class="subscribe-form" method="post" action="index.php?mod=page/jadwal&pg=detail_jadwal">
                            <div class="form-group">
                                <input type="text" name="cr" class="form-control" placeholder="Masukkan Nama Hari" />
                            </div>
                            <input class="btn btn-theme btn-subscribe" type="submit" value="Cari">
                        </form>
                    <?php } else {
						?>
                            <h3>Kritik & Saran</h3>
                            <p>Silahkan masukan kritik dan saran anda !</p>
                        <form class="subscribe-form" method="post" action="simpankritik.php">
                            <div class="form-group">
                                <textarea name="kritik" class="form-control" ></textarea>
                            </div>
                            <input class="btn btn-theme btn-subscribe" type="submit" value="Kirim">
                        </form>
                        <?php } ?>
                    </div><!--//footer-col-inner-->
                </div><!--//foooter-col--> 
                <div class="footer-col col-md-3 col-sm-12 contact">
                    <div class="footer-col-inner">
                        <h3>Kontak Kami</h3>
                        <div class="row">
                            <p class="adr clearfix col-md-12 col-sm-4">
                                <i class="fa fa-map-marker pull-left"></i>        
                                <span class="adr-group pull-left">       
                            <span class="street-address">Jl.</span> Alimudin Umar No. 163, Campang Raya,</span><span class="adr-group pull-left">Tanjung Karang Timur<br>
                              <span class="country-name">Kota Bandar Lampung</span>
                            </span> </p>
                            <p class="tel col-md-12 col-sm-4"><i class="fa fa-phone"></i>+627217627328</p>
                            <p class="email col-md-12 col-sm-4"><i class="fa fa-envelope"></i><a href="#">kliniknusantara@gmail.com</a></p>  
                        </div> 
                    </div><!--//footer-col-inner-->            
                </div><!--//foooter-col-->   
                </div>   
            </div>        
        </div><!--//footer-content-->
        <div class="bottom-bar">
            <div class="container">
                <div class="row">
                    <small class="copyright col-md-6 col-sm-12 col-xs-12">Copyright @ 2020 by <a href="#">Winndy</a></small>
                    <ul class="social pull-right col-md-6 col-sm-12 col-xs-12">
                      <li><a href="#" ><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" ><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" ><i class="fa fa-youtube"></i></a></li> 
                        <li><a href="#" ><i class="fa fa-google-plus"></i></a></li> 
                        <li class="row-end"><a href="#" ><i class="fa fa-rss"></i></a></li>
                    </ul><!--//social-->
                </div><!--//row-->
            </div><!--//container-->
        </div><!--//bottom-bar-->
    </footer><!--//footer-->
   
    <!-- Javascript -->          
    <script type="text/javascript" src="assets/front-end/plugins/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="assets/front-end/plugins/jquery-migrate-1.2.1.min.js"></script> 
    <script type="text/javascript" src="assets/front-end/plugins/bootstrap/js/bootstrap.min.js"></script> 

    <script type="text/javascript" src="assets/front-end/plugins/jquery.dataTables.min.js"></script> 
    <script type="text/javascript" src="assets/front-end/plugins/dataTables.bootstrap.js"></script> 
       
    <script type="text/javascript" src="assets/front-end/plugins/bootstrap-hover-dropdown.min.js"></script> 
    <script type="text/javascript" src="assets/front-end/plugins/back-to-top.js"></script>
    <script type="text/javascript" src="assets/front-end/plugins/jquery-placeholder/jquery.placeholder.js"></script>
    <script type="text/javascript" src="assets/front-end/plugins/pretty-photo/js/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="assets/front-end/plugins/flexslider/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="assets/front-end/plugins/jflickrfeed/jflickrfeed.min.js"></script> 
    <script type="text/javascript" src="assets/front-end/js/main.js"></script>   
     <script type="text/javascript">
            $(function() {
                $('#example1').dataTable();
            });
        </script>         
</body>

<!-- Mirrored from themes.3rdwavemedia.com/college-green/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 04 Feb 2015 12:53:45 GMT -->
</html> 

