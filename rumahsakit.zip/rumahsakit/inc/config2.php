<?php
mysql_connect("localhost","smpnseka","smpnseka_db");
mysql_select_db("smp2017");
?>