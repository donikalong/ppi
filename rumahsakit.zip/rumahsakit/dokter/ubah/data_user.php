
            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Pengguna</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title" style="text-align:right">
                                <?php
                                    if ($level=='1'){
                                ?>
                                <a href="index.php?mod=user&pg=form_input_user"><button class="btn btn-success m-b-5"> <i class="fa fa-plus"></i> <span>Tambah Pengguna</span> </button> 
                                <?php
                                    }
                                ?>
                                </h3>

                            </div>
                            <div class="panel-body">

                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Username</th>
                                                    <th>Password</th>
                                                    <th>Level</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php 
                                                    if ($level=='1'){
                                            		$sql = mysql_query("SELECT * FROM login");
                                                } else {
                                                    $sql = mysql_query("SELECT * FROM login WHERE username='$id_user'");
                                                }
                                            		while($data = mysql_fetch_array($sql)){
                                                
                                            	?>
                                                <tr>
                                                    <td><?php echo $data['username'] ?></td>
                                                    <td><?php echo $data['password'] ?></td>
                                                    <td><?php echo $data['akses'] ?></td>
                                                    <td>
                                                        <a href="index.php?mod=user&pg=form_edit_user&id_user=<?php echo $data['username'];?>"><button class="btn btn-icon btn-primary m-b-5"> <i class="fa fa-edit"></i> </button></a>
                                                        <?php
                                                            if ($level=='1'){
                                                        ?>
                                                        <a href="user/hapus_user.php?id_user=<?php echo $data['username'];?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?') ";><button class="btn btn-icon btn-danger m-b-5"> <i class="fa fa-remove"></i> </button></a>
                                                        <?php
                                                            }
                                                        ?>                                                       
                                                    </td>
                                               </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           