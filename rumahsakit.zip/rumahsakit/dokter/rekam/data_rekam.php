
            <!-- Page Content Start -->
            <!-- ================== -->
      
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Data Rekam Medis</h3> 
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               <!-- <h3 class="panel-title">Data Siswa</h3> -->
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-body table-responsive">
                                        <table id="datatable" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Pendaftaran</th>
                                                    <th>Tanggal</th>
                                                    <th>No RM</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Alamat</th>
                                                    <th>Telpon</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>Infeksi</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                     
                                            <tbody>
                                            	<?php
                                                    $user = $_SESSION['username']; 
                                            		$sql = mysql_query("SELECT * FROM pasien inner join pendaftaran on pasien.norm = pendaftaran.norm inner join rawat on pendaftaran.idpendaftaran = rawat.idpendaftaran inner join dokter on rawat.iddokter = dokter.iddokter WHERE dokter.username='$user' ORDER BY rawat.tglmasuk DESC");
                                                    $no = 1;
                                            		while($data = mysql_fetch_array($sql)){
                                                        $infeksi = $data['infeksi'];
                                            	?>
                                                <tr>
                                                    <td><?php echo $no++;   ?></td>
                                                    <td><?php echo $data['idpendaftaran'] ?></td>
                                                    <td><?php echo $data['tglmasuk'] ?></td>
                                                    <td><?php echo $data['norm'] ?></td>
                                                    <td><?php echo $data['namapasien'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['telpon'] ?></td>
                                                    <td><?php echo $data['jk'] ?></td>
                                                     <td><?php echo $data['infeksi'] ?></td>
                                                    <td>
                                                        <?php
                                                        if ($infeksi == "Scables"){
                                                            ?>
                                                                <a href="index.php?mod=rekam&pg=form_input_scables&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-info m-b-5"> Detail </button></a> 
                                                            <?php
                                                        }else if($infeksi == "Phlebitis"){
                                                            ?>
                                                                <a href="index.php?mod=rekam&pg=form_input_phlebitis&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-info m-b-5"> Detail </button></a> 
                                                            <?php
                                                        }else if($infeksi == "ISK"){
                                                            ?>
                                                                <a href="index.php?mod=rekam&pg=form_input_isk&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-info m-b-5"> Detail </button></a> 
                                                            <?php
                                                        }else if($infeksi == "Dekubitus"){
                                                            ?>
                                                                <a href="index.php?mod=rekam&pg=form_input_dekubitus&id_pendaftaran=<?php echo $data['idpendaftaran'];?>"><button class="btn btn-icon btn-info m-b-5"> Detail </button></a> 
                                                            <?php
                                                        }
                                                        ?>

                                                           
                                                    
                                                       

                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div> <!-- End Row -->

                

            </div>

           